//
//  Film.h
//  DatVeXemPhim
//
//  Created by admin on 3/25/15.
//  Copyright (c) 2015 ThuyNguyen. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Film : NSObject

@property (nonatomic, strong) NSString *filmContent;
@property (nonatomic, strong) NSDate *filmDateStart;
@property (nonatomic, strong) NSString *filmDirector;
@property (nonatomic, strong) NSString *filmID;
@property (nonatomic, strong) NSString *filmImage;
@property (nonatomic, strong) NSString *filmName;
@property (nonatomic, strong) NSNumber *filmTime;
@property (nonatomic, strong) NSString *filmType;
@property (nonatomic, strong) NSNumber *filmVote;
- (instancetype)initWithDictionary:(NSDictionary *)dic;
@end
