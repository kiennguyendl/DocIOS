//
//  FilmPlayingTableViewCell.h
//  Module2_BaiTap4_2
//
//  Created by Nguyễn Hoàng Dũng on 4/21/15.
//  Copyright (c) 2015 cscom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FilmPlayingTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *imvFilmImage;
@property (strong, nonatomic) IBOutlet UILabel *lblFilmName;
@property (strong, nonatomic) IBOutlet UIView *vFilmVote;
@property (strong, nonatomic) IBOutlet UILabel *lblFilmDateStart;

@end
