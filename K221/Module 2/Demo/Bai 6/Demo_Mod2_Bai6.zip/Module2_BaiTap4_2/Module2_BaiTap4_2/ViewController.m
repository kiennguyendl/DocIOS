//
//  ViewController.m
//  Module2_BaiTap4_2
//
//  Created by Nguyễn Hoàng Dũng on 4/21/15.
//  Copyright (c) 2015 cscom. All rights reserved.
//

#import "ViewController.h"
#import "Film.h"
#import "FilmPlayingTableViewCell.h"
#import "DataManager.h"
#import "UIColor+ExtraColor.h"
@interface ViewController ()<UITableViewDataSource, UITableViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
    //Lay du lieu tu file Data.plist
    self.filmsList = [[NSMutableArray alloc]init];
    NSString *filePathBundle = [[NSBundle mainBundle]pathForResource:@"Data" ofType:@"plist"];
    NSDictionary *root =[NSDictionary dictionaryWithContentsOfFile:filePathBundle];
    NSArray *films = [root objectForKey:@"FilmsPlaying"];
    for (NSDictionary *dic in films) {
        //khởi tạo một đối tượng film từ một NSDictionary truyền vào
        Film *f = [[Film alloc] initWithDictionary:dic];
        [self.filmsList addObject:f];
    }
    */
    
    //Su dung Singleton de lay du lieu tu Manager
    DataManager *defaultManager = [DataManager defaultDataManager];
    self.filmsList = defaultManager.filmPlayingList;
    
    self.tbvFilmPlaying.delegate = self;
    self.tbvFilmPlaying.dataSource = self;
   
    //Tuy chinh Navigation bar
    UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 150, 30)];
    lblTitle.text = @"Films Playing";
    [lblTitle setTextColor:[UIColor blueLightColor]];
    lblTitle.textAlignment = NSTextAlignmentCenter;
    
    //Thiet lap mau nen cho Navigation bar
    [self.navigationController.navigationBar setBarTintColor:[UIColor lightGrayColor]];
    
    [self.navigationItem setTitleView:lblTitle];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark Table View
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //trả về số phim trong danh sách
    return self.filmsList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellID = @"cell_id";
    FilmPlayingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];

    //lấy phim ở vị trí của dòng hiện tại
    Film *filmDetail = [self.filmsList objectAtIndex:indexPath.row];
    //truyền dữ liệu lên các control trên cell thông qua các IBOutlet đã kết nối.
    cell.imvFilmImage.image = [UIImage imageNamed:filmDetail.filmImage];
    cell.lblFilmName.text = filmDetail.filmName;
    //để định dạng ngày tháng về dạng ngày/tháng/năm ta dùng NSDateFormatter
    NSDateFormatter* format = [[NSDateFormatter alloc]init];
    //Xét định dạng: 23/09/2015
    [format setDateFormat:@"dd/MM/yyyy"];
    //Tạo ra chuỗi ngày hiển thị theo định dạng đã được xét ở trên từ tham số ngày truyền vào
    NSString *date = [format stringFromDate:filmDetail.filmDateStart];
    cell.lblFilmDateStart.text = [NSString stringWithFormat:@"Ngày: %@",date];
    //Tính số hình ngôi sao sẽ hiển thị với điểm bình chọn cao nhất là 10 và số ngôi sao hiển thị tương ứng là 5.
    //Do đó ta lấy điểm bình chọn chia 2 và làm tròn số
    //ví dụ: 4.25 => 4 || 4.75 => 5
    int star = round([filmDetail.filmVote doubleValue]/2.0f);
    //x để lưu tọa độ của hình ngôi sao
    int x = 0;
    for (int i = 0; i < star; i++) {
        //khởi tạo imageview để chứa hình ngôi sao
        UIImageView *imvStar = [[UIImageView alloc]initWithFrame:CGRectMake(x, 0, 20, 20)];
        imvStar.image = [UIImage imageNamed:@"star.png"];
        //hiển thị hình ngôi sao lên view
        [cell.vFilmVote addSubview:imvStar];
        //tính tọa độ hình ngôi sao tiếp theo
        x+=20;
    }
    
    //trả về ô đã truyền đầy đủ dữ liệu
    return cell;
}

@end
