//
//  ViewController.h
//  Module2_BaiTap4_2
//
//  Created by Nguyễn Hoàng Dũng on 4/21/15.
//  Copyright (c) 2015 cscom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITableView *tbvFilmPlaying;
@property (strong, nonatomic) NSMutableArray *filmsList;
@end

