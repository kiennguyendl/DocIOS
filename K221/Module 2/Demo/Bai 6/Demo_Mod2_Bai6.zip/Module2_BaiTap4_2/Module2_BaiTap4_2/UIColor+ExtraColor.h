//
//  UIColor+ExtraColor.h
//  Module2_BaiTap4_2
//
//  Created by TNKHANH on 5/6/16.
//  Copyright © 2016 cscom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (ExtraColor)
+(UIColor *)blueLightColor;
+(UIColor *)myFavouriteColor;

@end
