//
//  Film.m
//  DatVeXemPhim
//
//  Created by admin on 3/25/15.
//  Copyright (c) 2015 ThuyNguyen. All rights reserved.
//

#import "Film.h"


@implementation Film

- (instancetype)initWithDictionary:(NSDictionary *)dic{
    self.filmContent = [dic objectForKey:@"ZFILMCONTENT"];
    self.filmDateStart = [dic objectForKey:@"ZFILMDATESTART"];
    self.filmDirector = [dic objectForKey:@"ZFILMDIRECTOR"];
    self.filmID = [dic objectForKey:@"ZFILMID"];
    self.filmImage = [dic objectForKey:@"ZFILMIMAGE"];
    self.filmName = [dic objectForKey:@"ZFILMNAME"];
    self.filmTime = [dic objectForKey:@"ZFILMTIME"];
    self.filmType = [dic objectForKey:@"ZFILMTYPE"];
    self.filmVote = [dic objectForKey:@"ZFILMVOTE"];
    return self;
}
@end
