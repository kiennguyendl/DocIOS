//
//  ViewController.m
//  Demo_NSUserDefault
//
//  Created by TNKHANH on 5/6/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Lay NSUserDefaults cua he thong
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    //Lay du lieu luu trong user default
    NSString *name = [userDefault objectForKey:@"name"];
    NSNumber *poor = [userDefault objectForKey:@"poor"];
    NSDate *birthDay = [userDefault objectForKey:@"birthDay"];
    //Update UI
    self.txtName.text = name;
    [self.swIsPoor setOn:[poor intValue] == 1 ? true : false];
    [self.datePicker setDate:birthDay];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd-MM-yyyy"];
    self.lblBirthday.text = [dateFormatter stringFromDate:birthDay];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)save:(id)sender {
    //An ban phim
    [self.txtName resignFirstResponder];
    
    NSString *name = self.txtName.text;
    BOOL isPoor = self.swIsPoor.isOn;
    NSNumber *poor = [NSNumber numberWithBool:isPoor];
    NSDate *birthDay = [self.datePicker date];
    
    //Khoi tao NSUserDefault de luu du lieu
    NSUserDefaults  *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:name forKey:@"name"];
    [userDefault setObject:poor forKey:@"poor"];
    [userDefault setObject:birthDay forKey:@"birthDay"];
    
    //Dong bo NSUserDefaults
    if ([userDefault synchronize]){
        NSLog(@"Data saved");
    }
    
}

- (IBAction)datePickerDidChange:(id)sender {
    UIDatePicker *picker = (UIDatePicker *)sender;
    NSDate *birthDay = [picker date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd-MM-yyyy"];
    self.lblBirthday.text = [dateFormatter stringFromDate:birthDay];
}
@end
