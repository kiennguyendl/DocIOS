//
//  ViewController.h
//  Demo_Mod2_Bai3
//
//  Created by TNKHANH on 4/4/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)pushB:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtContent;

@end

