//
//  CViewController.m
//  Demo_Mod2_Bai3
//
//  Created by TNKHANH on 4/4/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "CViewController.h"
#import "ViewController.h"
@interface CViewController ()

@end

@implementation CViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Thiet lap title
    self.title  = @"C View";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)popToRoot:(id)sender {

    //Quay ve view lien truoc
    //[self.navigationController popViewControllerAnimated:true];
    
    //Quay ve view root trong navigation stack
    //Cach 1
    //[self.navigationController popToRootViewControllerAnimated:true];
    //Cach 2
    //NSArray *viewControllers = self.navigationController.viewControllers;
    //[self.navigationController popToViewController:viewControllers[0] animated:true];
    //Cach 3
    for (UIViewController *viewController in self.navigationController.viewControllers) {
        if ([viewController isKindOfClass:[ViewController class]]) {
            [self.navigationController popToViewController:viewController animated:true];
        }
    }
}
@end
