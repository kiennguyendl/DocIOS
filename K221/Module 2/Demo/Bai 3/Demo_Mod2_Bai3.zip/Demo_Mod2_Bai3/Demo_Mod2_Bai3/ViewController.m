//
//  ViewController.m
//  Demo_Mod2_Bai3
//
//  Created by TNKHANH on 4/4/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "ViewController.h"
#import "BViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //Thiet lap back button cho navigation item
    UIBarButtonItem *backButton = [[UIBarButtonItem alloc] initWithTitle:@"quay ve" style:UIBarButtonItemStyleDone target:self action:nil];
    [self.navigationItem setBackBarButtonItem:backButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(void)viewWillAppear:(BOOL)animated{
    self.txtContent.text = @"";
}
//Ham duoc goi khi bam vao doi tuong co su dung segue
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"pushB"]) {
        BViewController *bView = segue.destinationViewController;
        //Pass Data
        bView.data = self.txtContent.text;
        
    }
}
- (IBAction)pushB:(id)sender {
    //Khoi tao viewController voi StoryBoardId
    BViewController *bView = [self.storyboard instantiateViewControllerWithIdentifier:@"BViewController"];
    //Pass data
    bView.data = self.txtContent.text;
    //Push
    [self.navigationController pushViewController:bView animated:true];
    
}
@end
