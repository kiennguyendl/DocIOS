//
//  BViewController.m
//  Demo_Mod2_Bai3
//
//  Created by TNKHANH on 4/4/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "BViewController.h"
#import "CViewController.h"
@interface BViewController ()

@end

@implementation BViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.lblContent.text = self.data;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)pushC:(id)sender {
    //KHoi tao viewController voi nib file
    CViewController *cView = [[CViewController alloc] initWithNibName:@"CViewController" bundle:nil];
    //Push
    [self.navigationController pushViewController:cView animated:false];
    cView.title = @"View C";
}
@end
