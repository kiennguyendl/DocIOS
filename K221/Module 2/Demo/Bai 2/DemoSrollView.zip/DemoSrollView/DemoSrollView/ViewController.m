//
//  ViewController.m
//  DemoSrollView
//
//  Created by TNKHANH on 4/15/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpScrollView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Thiet lap scrollView co chua imageView
-(void)setUpScrollView{
    //Khoi tao hinh co kich thuoc la kich thuoc cua scrollView
    self.imageView = [[UIImageView alloc] initWithFrame:self.scrollView.frame];
    //Gan hinh hien thi tren imageView
    self.imageView.image = [UIImage imageNamed:@"hinh1.jpg"];
    
    //Thiet lap imageView la subview cua scrollView
    [self.scrollView addSubview:self.imageView];
    
    //Thiet lap kich thuoc noi dung cho scrollView
    [self.scrollView setContentSize:CGSizeMake(self.imageView.frame.size.width, self.imageView.frame.size.height)];
    
    //Uy thac cho view
    self.scrollView.delegate = self;
    
    //Thiet lap ti le phong to/thu nho cua scrollView
    [self.scrollView setMinimumZoomScale:0.5f];
    [self.scrollView setMaximumZoomScale:3.0f];
}
//Canh giua imageView tren screen sau khi zoom
-(void)adjustImageViewToCenter{
    //Lay kich thuoc khung cua scrollView
    CGSize boundSize = self.scrollView.bounds.size;
    //Lay fram cua imageView
    CGRect contentFrame = self.imageView.frame;
    
    //Kiem tra trong truong hop thu nho
    if (contentFrame.size.width < boundSize.width) {
        contentFrame.origin.x = (boundSize.width - contentFrame.size.width)/2;
    }
    if (contentFrame.size.height < boundSize.height) {
        contentFrame.origin.y  = (boundSize.height - contentFrame.size.height)/2;
    }
    //Thiet lap lai frame moi cho imageView
    [self.imageView setFrame:contentFrame];
}
#pragma mark UIScrollViewDelegate
//Chi dinh view duoc zoom trong scrollView
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return self.imageView;
}
//Ham nay tu dong goi sau khi scroll/zoom xong
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    NSLog(@"Finish");
    //Canh imageView giua man hinh
    [self adjustImageViewToCenter];
}


@end
