//
//  PageViewController.m
//  DemoSrollView
//
//  Created by TNKHANH on 4/15/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "PageViewController.h"

@interface PageViewController ()

@end

@implementation PageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpScrollView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Thiet lap scrollView co 3 imageView
-(void)setUpScrollView{
    int x1 = 0;
    int y1 = 0;
    //Vong lap tao ra cac imageView va them vao scrollView
    for (int i=0; i < 3; i++) {
        //Khoi tao image theo imageName
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"hinh%d.jpg",i+1]];
        //Khoi tao imageView de chua hinh voi kich thuoc cua scrollView
//        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(x1, 0, self.scrollView.frame.size.width, self.scrollView.frame.size.height)];
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, y1, self.scrollView.frame.size.width, self.scrollView.frame.size.height)];
        //Gan image cho imageView
        imageView.image = image;
        
        //Them imageView vao scrollView
        [self.scrollView addSubview:imageView];
//        x1 += imageView.frame.size.width;
        y1 += imageView.frame.size.height;
    }
    
    //Thiet lap kich thuoc noi dung cho scrollView
    //[self.scrollView setContentSize:CGSizeMake(x1, self.scrollView.frame.size.height)];
    [self.scrollView setContentSize:CGSizeMake(self.scrollView.frame.size.width, y1)];
    
    //Thiet lap che do phan trang
    self.scrollView.pagingEnabled = true;
    
    //Thiet lap so luong trang cho pageControl
    [self.pageControl setNumberOfPages:3];
    //Tat hieu ung bounces khi cham le
    self.scrollView.bounces = false;
    //Uy thac view
    self.scrollView.delegate = self;
}
#pragma mark scollview delegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{

    //Tinh toan page hien tai
    //int page = scrollView.contentOffset.x / scrollView.frame.size.width;
    int page = scrollView.contentOffset.y / scrollView.frame.size.height;
    //Thiet lap page hien tai cho pageControl
    self.pageControl.currentPage = page;
}
@end
