//
//  ViewController.h
//  DemoSrollView
//
//  Created by TNKHANH on 4/15/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (nonatomic,strong) UIImageView *imageView;

@end

