//
//  PhotoCameraViewController.m
//  Setting_App
//
//  Created by TNKHANH on 5/16/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "PhotoCameraViewController.h"

@interface PhotoCameraViewController ()

@end

@implementation PhotoCameraViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    NSString *cellId = @"Cell";
    if (!cell ) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    UISwitch *mySwitch = [[UISwitch alloc] initWithFrame:CGRectMake(cell.frame.size.width-20, 7, 30, 25)];
    mySwitch.tag = indexPath.section;
    [mySwitch addTarget:self action:@selector(switchChange:) forControlEvents:UIControlEventValueChanged];
    
    switch (indexPath.section) {
        case 0:{
            cell.textLabel.text = @"iCloud Photo Library";
            
            [mySwitch setOn:[[userDefaults objectForKey:@"p0"] boolValue]];
            break;
        }
        case 1:{
            cell.textLabel.text = @"Summarize Photos";
            [mySwitch setOn:[[userDefaults objectForKey:@"p1"] boolValue]];
            break;
        }
        case 2:{
            cell.textLabel.text = @"Grid";
            [mySwitch setOn:[[userDefaults objectForKey:@"p2"] boolValue]];
            break;
            
        }
        default:
            break;
    }
    
    [cell.contentView addSubview:mySwitch];

    // Configure the cell...
    
    return cell;
}

-(void)switchChange:(UISwitch *)sender{
    //NSLog(@"%ld",sender.tag);
    //Luu xuong NSUserDefaults
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    if (sender.tag == 0) {
        [userDefaults setObject:[NSNumber numberWithBool:sender.isOn] forKey:@"p0"];
    }
    if (sender.tag == 1) {
        [userDefaults setObject:[NSNumber numberWithBool:sender.isOn] forKey:@"p1"];
    }
    if (sender.tag == 2) {
        [userDefaults setObject:[NSNumber numberWithBool:sender.isOn] forKey:@"p2"];
    }
    if ([userDefaults synchronize]) {
        NSLog(@"Saved");
    }
    
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 1) {
        return @"Photos Tab";
    }
    if (section == 2) {
        return @"Grid";
    }
    return @"";
}
-(NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{
    if (section == 0) {
        return @"Automatically upload and store your entire library in iCloud to access photos and videos from all your devices";
    }
    if (section == 1) {
        return @"The photos tab show every photo in your library in all views. You can choose compact, summarize views for Collections and Years";
    }
    return @"";
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
