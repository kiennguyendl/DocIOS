//
//  ViewController.m
//  Setting_App
//
//  Created by TNKHANH on 5/16/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"
#import "GeneralViewController.h"
#import "PhotoCameraViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 4;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 2;
    }
    if (section == 1) {
        return 6;
    }
    if (section == 2) {
        return 4;
    }
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        
    }
    switch (indexPath.section) {
        case 0://2 rows
            if (indexPath.row == 0) {
                cell.imageView.image = [UIImage imageNamed:@"image1.png"];
                cell.textLabel.text = @"General";
            }
            else
                cell.textLabel.text = @"Privacy";
            break;
        case 1:// 6 rows
            switch (indexPath.row) {
                case 0:
                    cell.textLabel.text = @"iCloud";
                    break;
                case 1:
                    cell.textLabel.text = @"Maps";
                    break;
                case 2:
                    cell.textLabel.text = @"News";
                    break;
                case 3:
                    cell.textLabel.text = @"Safari";
                    break;
                case 4:
                    cell.textLabel.text = @"Photos & Camera";
                    cell.imageView.image = [UIImage imageNamed:@"image2.png"];
                    break;
                default:
                    cell.textLabel.text = @"Game Center";
                    break;
            }
            break;
        case 2://4 rows
            switch (indexPath.row) {
                case 0:
                    cell.textLabel.text = @"Twitter";
                    break;
                case 1:
                    cell.textLabel.text = @"Facebook";
                    break;
                case 2:
                    cell.textLabel.text = @"Flickr";
                    break;
                default:
                    cell.textLabel.text = @"Vimeo";
                    break;
            }
            break;
            
        default:
            cell.textLabel.text = @"Developer";
           
            break;
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0 && indexPath.row == 0) {
        GeneralViewController *detailView  = [self.storyboard instantiateViewControllerWithIdentifier:@"GeneralViewController"];
        detailView.title = @"General";
        [self.navigationController pushViewController:detailView animated:true];
    }
    if (indexPath.section == 1 && indexPath.row == 4) {
        PhotoCameraViewController *detailView  = [self.storyboard instantiateViewControllerWithIdentifier:@"PhotoCameraViewController"];
        detailView.title = @"Photos & Camera";
        [self.navigationController pushViewController:detailView animated:true];
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:true];
}

@end
