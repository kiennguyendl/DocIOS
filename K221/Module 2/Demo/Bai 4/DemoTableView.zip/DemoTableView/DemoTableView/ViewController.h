//
//  ViewController.h
//  DemoTableView
//
//  Created by TNKHANH on 4/22/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@end

