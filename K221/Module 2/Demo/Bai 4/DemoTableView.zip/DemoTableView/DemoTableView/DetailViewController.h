//
//  DetailViewController.h
//  DemoTableView
//
//  Created by TNKHANH on 4/22/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic, strong)NSDictionary *currentItem;
@end
