//
//  TableViewController.h
//  DemoTableView
//
//  Created by TNKHANH on 4/22/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController
@property (nonatomic, strong)NSMutableDictionary *dataSource;
@property (nonatomic, strong)NSMutableArray *dataList;
@end
