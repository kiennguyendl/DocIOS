//
//  TableViewController.m
//  DemoTableView
//
//  Created by TNKHANH on 4/22/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "TableViewController.h"
#import "DetailViewController.h"
@interface TableViewController ()

@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   //Tao du lieu
    NSArray *countryList = @[@"Viet Nam",@"USA",@"England",@"France",@"Japan",@"Singapore"];
    NSArray *capitalList = @[@"Ha Noi",@"Washington DC",@"London",@"Paris",@"Tokyo",@"Singapore"];
    NSArray *flagList = @[@"vietnam.png",@"america.png",@"england.png",@"france.png",@"japan.png",@"singapore.png"];
    
    
    self.dataList = [[NSMutableArray alloc] init];
    for (int i =0; i<countryList.count; i++) {
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        [item setObject:countryList[i] forKey:@"country"];
        [item setObject:capitalList[i] forKey:@"capital"];
        [item setObject:flagList[i] forKey:@"flag"];
        
        //Them item vao dataList
        [self.dataList addObject:item];
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    

    // Configure the cell...
    NSDictionary *item = self.dataList[indexPath.row];
    
    NSString *countryName = item[@"country"];
    NSString *capitalName = item[@"capital"];
    NSString *flagName = item[@"flag"];
    
    cell.textLabel.text = countryName;
    cell.detailTextLabel.text = capitalName;
    cell.imageView.image = [UIImage imageNamed:flagName];
    
    return cell;
}

#pragma mark Table View Delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //Khoi tao view voi story board
    DetailViewController *detailView = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    //Pass data
    NSDictionary *currentItem = self.dataList[indexPath.row];
    detailView.currentItem = currentItem;
    
    //Push view
    [self.navigationController pushViewController:detailView animated:true];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
