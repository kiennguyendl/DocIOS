//
//  CustomTableViewCell.m
//  DemoTableView
//
//  Created by TNKHANH on 4/25/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "CustomTableViewCell.h"

@implementation CustomTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)layoutSubviews{
    self.flagImageView.layer.cornerRadius = self.flagImageView.frame.size.width/2;
    self.flagImageView.clipsToBounds = true;
    //self.backgroundColor = [UIColor lightGrayColor];
}

@end
