//
//  ViewController.m
//  DemoTableView
//
//  Created by TNKHANH on 4/22/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark Table View Datasource
//So luong section trong tableview
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}
//So luong row trong tung section
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 6;
    }
    if (section == 1) {
        return 15;
    }
    return 20;
}
//Mo ta cell trong tableview
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    //Mo ta data cho tung cell
    cell.textLabel.text = [NSString stringWithFormat:@"Row %ld - Section %ld",indexPath.row,indexPath.section];
    cell.detailTextLabel.text = @"Subtitle";
    
    //Accessory Type
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    return cell;
}

@end
