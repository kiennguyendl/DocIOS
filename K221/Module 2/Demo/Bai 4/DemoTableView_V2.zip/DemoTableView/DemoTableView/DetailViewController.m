//
//  DetailViewController.m
//  DemoTableView
//
//  Created by TNKHANH on 4/22/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    //Tieu de tren thanh navigation
    self.title = self.currentItem[@"country"];
    //ImageView
    self.imageView.image = [UIImage imageNamed:self.currentItem[@"flag"]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
