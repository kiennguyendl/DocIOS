//
//  DetailViewController.h
//  DemoCollectionView
//
//  Created by TNKHANH on 5/9/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic, strong)NSString *imageName;

@end
