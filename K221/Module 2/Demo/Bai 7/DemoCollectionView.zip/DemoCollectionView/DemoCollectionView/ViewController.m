//
//  ViewController.m
//  DemoCollectionView
//
//  Created by TNKHANH on 5/9/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"
#import "DetailViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.photoList = [[NSMutableArray alloc] init];
    for (int i=0;i<16;i++) {
        NSString *photoName = [NSString stringWithFormat:@"photo%d.jpg",i+1];
        [self.photoList addObject:photoName];
    }
    self.btnDelete.enabled = false;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark Collection View Datasource
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.photoList.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"Cell";
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellId forIndexPath:indexPath];
    
    //Casting imageView voi tag
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:10];
    //Lay hinh tu mang photoList
    UIImage *image = [UIImage imageNamed:self.photoList[indexPath.row]];
    //Gan image cho imageView
    imageView.image = image;
    
    
    return cell;
}

#pragma mark Collection View Flow layout
//Tuy chinh kich thuoc cell trong item
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    return CGSizeMake(collectionView.frame.size.width/4, collectionView.frame.size.width/4);
}
#pragma mark Collection View Delegate
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (!self.isSelectMultiple) {//Neu KHONG chon nhieu

        DetailViewController *detailView = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
        //Pass data
        detailView.imageName = self.photoList[indexPath.row];
        //Push view
        [self.navigationController pushViewController:detailView animated:true];
    }
    else{
        //Them phan tu vao mang hinh duoc lua chon
        [self.selectedImages addObject:self.photoList[indexPath.row]];
        self.btnDelete.enabled = true;
        //Lay cell dang duoc chon
        UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
        cell.selectedBackgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pic_frame.png"]];
        
        //Casting imageView voi tag
        //UIImageView *imageView = (UIImageView *)[cell viewWithTag:10];
        //[imageView setFrame:CGRectMake(5, 5, cell.frame.size.width - 10, cell.frame.size.height - 10)];
        [cell bringSubviewToFront:cell.selectedBackgroundView];
    }
}
-(void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:10];
    //[imageView setFrame:CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height)];
    [cell bringSubviewToFront:imageView];
    [self.selectedImages removeObject:self.photoList[indexPath.item]];
    if (self.selectedImages.count == 0) { //Kiem tra khi khong co hinh nao duoc chon
        self.btnDelete.enabled = false;
    }
}

- (IBAction)didDeleteImages:(id)sender {
    NSString *deleteMessage = [NSString stringWithFormat:@"Delete %ld photos",self.selectedImages.count];
    //Xay dung alert Controller dang Action sheet
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:@"Confirm delete image" preferredStyle:UIAlertControllerStyleActionSheet];
    
    //Xay dung action cho alert controller
    UIAlertAction *deleteAction = [UIAlertAction actionWithTitle:deleteMessage style:UIAlertActionStyleDestructive handler:^(UIAlertAction *deleteAction){
        //Xu ly xoa hinh dang chon
        for (NSString *item in self.selectedImages) {
            [self.photoList removeObject:item];
        }
        self.selectedImages = [[NSMutableArray alloc] init];
        self.btnDelete.enabled = false;
        [self.collectionView reloadData];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *cancelAction){
        
    }];

    //Them action cho alert
    [alert addAction:deleteAction];
    [alert addAction:cancelAction];
    
    
    //Hien thi alert controller
    [self presentViewController:alert animated:true completion:nil];
}

- (IBAction)selectMultiple:(id)sender {
    //Casting
    UIBarButtonItem *button = (UIBarButtonItem *)sender;
    //Kiem tra trang thai
    if (!self.isSelectMultiple) {
        //Cho phep chon nhieu item tren collection View
        self.collectionView.allowsMultipleSelection = true;
        
        //Thiet lap lai tieu de cho button
        [button setTitle:@"Cancel"];
        
        //Khoi tao mang hinh duoc chon
        self.selectedImages = [[NSMutableArray alloc] init];
    }
    else{
        
        self.collectionView.allowsMultipleSelection = false;
        [button setTitle:@"Select"];
        
        self.btnDelete.enabled = false;
        [self.collectionView reloadData];
    }
    
    //Chuyen trang thai chon mot -> chon nhieu va nguoc lai
    self.isSelectMultiple = !self.isSelectMultiple;
    
}
@end
