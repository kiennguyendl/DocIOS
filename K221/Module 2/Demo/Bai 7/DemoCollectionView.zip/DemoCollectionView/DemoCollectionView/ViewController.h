//
//  ViewController.h
//  DemoCollectionView
//
//  Created by TNKHANH on 5/9/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong)NSMutableArray *photoList;
- (IBAction)didDeleteImages:(id)sender;
- (IBAction)selectMultiple:(id)sender;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *btnDelete;

@property (nonatomic, strong)NSMutableArray *selectedImages;
@property (nonatomic)BOOL isSelectMultiple;
@end

