//
//  DataManager.h
//  Module2_BaiTap4_2
//
//  Created by TNKHANH on 5/6/16.
//  Copyright © 2016 cscom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataManager : NSObject
//Khai bao mang luu tru danh sach film dang chieu
@property (nonatomic, strong)NSMutableArray *filmPlayingList;
@property (nonatomic, strong)NSMutableArray *filmWillplayList;
//Khai bao phuong thuc static, tra ve doi tuong thuoc lop DataManger
+(id)defaultDataManager;
@end
