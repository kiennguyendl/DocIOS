//
//  FilmCollectionViewController.m
//  Module2_BaiTap4_2
//
//  Created by TNKHANH on 5/13/16.
//  Copyright © 2016 cscom. All rights reserved.
//

#import "FilmCollectionViewController.h"
#import "CustomCollectionViewCell.h"
#import "Film.h"
@interface FilmCollectionViewController ()

@end

@implementation FilmCollectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    DataManager *dataManager = [DataManager defaultDataManager];
    self.filmWillPlayList = dataManager.filmPlayingList;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.filmWillPlayList.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId;
    if (indexPath.item == 0) {
        cellId = @"Cell1";
    }
    else{
        cellId = @"Cell2";
    }
    CustomCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellId forIndexPath:indexPath];

    
    Film *currentFilm = self.filmWillPlayList[indexPath.item];
    cell.lblTitle.text = currentFilm.filmName;
    cell.filmImageView.image = [UIImage imageNamed:currentFilm.filmImage];
    
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.item == 0) {
        return CGSizeMake(collectionView.frame.size.width, 200);
    }
    return CGSizeMake((collectionView.frame.size.width-10)/2, 200);
}
-(void)viewWillLayoutSubviews{
    //NSLog(@"abc");
    [self.collectionView reloadData];
}

@end
