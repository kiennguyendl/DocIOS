//
//  CustomCollectionViewCell.h
//  Module2_BaiTap4_2
//
//  Created by TNKHANH on 5/13/16.
//  Copyright © 2016 cscom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCollectionViewCell : UICollectionViewCell
@property (nonatomic, weak)IBOutlet UILabel *lblTitle;
@property (nonatomic, weak)IBOutlet UIImageView *filmImageView;
@end
