//
//  FilmCollectionViewController.h
//  Module2_BaiTap4_2
//
//  Created by TNKHANH on 5/13/16.
//  Copyright © 2016 cscom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataManager.h"
@interface FilmCollectionViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong)NSMutableArray *filmWillPlayList;
@end
