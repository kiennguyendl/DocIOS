//
//  main.m
//  Module2_BaiTap4_2
//
//  Created by Nguyễn Hoàng Dũng on 4/21/15.
//  Copyright (c) 2015 cscom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
