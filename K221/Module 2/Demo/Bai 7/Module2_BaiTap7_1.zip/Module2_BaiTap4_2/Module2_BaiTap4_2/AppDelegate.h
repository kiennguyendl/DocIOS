//
//  AppDelegate.h
//  Module2_BaiTap4_2
//
//  Created by Nguyễn Hoàng Dũng on 4/21/15.
//  Copyright (c) 2015 cscom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

