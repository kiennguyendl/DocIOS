//
//  DataManager.m
//  Module2_BaiTap4_2
//
//  Created by TNKHANH on 5/6/16.
//  Copyright © 2016 cscom. All rights reserved.
//

#import "DataManager.h"
#import "Film.h"
@implementation DataManager
+(id)defaultDataManager{
    static DataManager *instance;
    
    if (instance == nil) {//Neu doi tuong chua ton tai
        instance = [[DataManager alloc]  init];
        //Goi phuong thuc tai du lieu
        [instance loadData];
    }
    return instance;
}


//Phuong thuc doc file plist va dua vao mang filmPlayingList
-(void)loadData{
    //Khoi tao mang filmPlayingList
    self.filmPlayingList = [[NSMutableArray alloc] init];
    self.filmWillplayList = [[NSMutableArray alloc] init];
    //Lay duong dan Data.plist trong bundle
    NSString *filePathBundle = [[NSBundle mainBundle]pathForResource:@"Data" ofType:@"plist"];
    
    NSDictionary *root =[NSDictionary dictionaryWithContentsOfFile:filePathBundle];
    NSArray *films = [root objectForKey:@"FilmsPlaying"];
    NSArray *filmsWillPlay = [root objectForKey:@"FilmsWillPlay"];
    for (NSDictionary *dic in films) {
        //khởi tạo một đối tượng film từ một NSDictionary truyền vào
        Film *f = [[Film alloc] initWithDictionary:dic];
        [self.filmPlayingList addObject:f];
    }
    for (NSDictionary *dic in filmsWillPlay) {
        //khởi tạo một đối tượng film từ một NSDictionary truyền vào
        Film *f = [[Film alloc] initWithDictionary:dic];
        [self.filmWillplayList addObject:f];
    }
    
}

@end
