//
//  UIColor+ExtraColor.m
//  Module2_BaiTap4_2
//
//  Created by TNKHANH on 5/6/16.
//  Copyright © 2016 cscom. All rights reserved.
//

#import "UIColor+ExtraColor.h"

@implementation UIColor (ExtraColor)
+(UIColor *)blueLightColor{
    return [UIColor colorWithRed:0/255.f green:100/255.f blue:255/255.f alpha:1];
}
+(UIColor *)myFavouriteColor{
    return [UIColor colorWithRed:247/255.f green:159/255.f blue:129/255.f alpha:1];
}
@end
