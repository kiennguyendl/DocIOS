//
//  CustomCollectionViewCell.m
//  Module2_BaiTap4_2
//
//  Created by TNKHANH on 5/13/16.
//  Copyright © 2016 cscom. All rights reserved.
//

#import "CustomCollectionViewCell.h"

@implementation CustomCollectionViewCell

@end
