//
//  ViewController.m
//  DemoPickerView_Tabbar
//
//  Created by TNKHANH on 4/29/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIPickerViewDataSource,UIPickerViewDelegate>

@end

@implementation ViewController
enum color{
    Red = 0,
    Green = 1,
    Blue = 2,
    Yellow = 3,
    White = 4
};
- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataList = @[
                      @[@"a",@"s",@"d",@"f",@"g"],
                      @[@"q",@"w",@"e",@"r",@"t"],
                      @[@"z",@"x",@"c",@"v"]
                      ];
    
    self.colorList = @[@"Red",@"Green",@"Blue",@"Yellow",@"White"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark Picker View Datasource
//So luong component cho picker
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    if (pickerView == self.colorPickerView) {
        return 1;
    }
    return self.dataList.count;
}
//So luong row trong tung component
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (pickerView == self.colorPickerView) {
        return self.colorList.count;
    }
    return [self.dataList[component] count];
}

#pragma mark Picker View Delegate
//Noi dung dang String hien thi tren tung dong cua component
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if (pickerView == self.colorPickerView) {
        return self.colorList[row];
    }
    return self.dataList[component][row];
}
//Xu ly su kien khi scroll component
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if (pickerView == self.colorPickerView) {
        enum color myColor = (int)row;
        switch (myColor) {
            case Red:
                self.view.backgroundColor = [UIColor redColor];
                break;
            case Green:
                self.view.backgroundColor = [UIColor greenColor];
                break;
            case Blue:
                self.view.backgroundColor = [UIColor blueColor];
                break;
            case Yellow:
                self.view.backgroundColor = [UIColor yellowColor];
                break;
            case White:
                self.view.backgroundColor = [UIColor whiteColor];
                [self.colorPickerView removeFromSuperview];
                break;
            default:
                break;
        }
    }
    else{
        NSLog(@"%@",self.dataList[component][row]);
    }
}

- (IBAction)didClickPicker:(id)sender {
    if (self.colorPickerView) {
        [self.colorPickerView removeFromSuperview];
    }
    //Khoi tao pickerview voi frame
    CGRect pickerViewFrame = CGRectMake(0, self.view.frame.size.height-200, self.view.frame.size.width, 200);
    self.colorPickerView = [[UIPickerView alloc] initWithFrame:pickerViewFrame];
    //Thiet lap delegate va datasource
    self.colorPickerView.delegate = self;
    self.colorPickerView.dataSource = self;
    
    //Thiet lap mau nen cho pickerview
    [self.colorPickerView setBackgroundColor:[UIColor lightGrayColor]];
    
    //Them pickerview vao view
    [self.view addSubview:self.colorPickerView];
}
@end
