//
//  DatePickerViewController.h
//  DemoPickerView_Tabbar
//
//  Created by TNKHANH on 4/29/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DatePickerViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lblDate;
- (IBAction)dateChanged:(UIDatePicker *)sender;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;

@end
