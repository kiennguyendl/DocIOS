//
//  AppDelegate.h
//  DemoPickerView_Tabbar
//
//  Created by TNKHANH on 4/29/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

