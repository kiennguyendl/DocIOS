//
//  DatePickerViewController.m
//  DemoPickerView_Tabbar
//
//  Created by TNKHANH on 4/29/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "DatePickerViewController.h"
#define kFormat @"EEEE dd/MM/yyyy HH:mm:ss a"
@interface DatePickerViewController ()

@end

@implementation DatePickerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.lblDate.text = [self getStringWithDate:self.datePicker.date andFormat:kFormat];
    
    NSLocale *viLocale = [NSLocale localeWithLocaleIdentifier:@"vi"];
    [self.datePicker setLocale:viLocale];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSString *)getStringWithDate:(NSDate *)date andFormat:(NSString *)format{
    //Khoi tao dinh dang ngay thang
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //Thiet lap format cho ngay thang can hien thi
    [dateFormatter setDateFormat:format];
    //Tao locale theo identifier
    NSLocale *viLocale = [NSLocale localeWithLocaleIdentifier:@"vi"];
    //Thiet lap locale cho dateformatter
    [dateFormatter setLocale:viLocale];
    
    //Convert NSDate->NSString
    return [dateFormatter stringFromDate:date];
}

- (IBAction)dateChanged:(UIDatePicker *)sender {
    //Lay thoi gian hien tai cua datePicker
    NSDate *currentDate = sender.date;
    
    self.lblDate.text = [self getStringWithDate:currentDate andFormat:kFormat];
    
}
@end
