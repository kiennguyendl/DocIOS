//
//  ViewController.h
//  DemoPickerView_Tabbar
//
//  Created by TNKHANH on 4/29/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic, strong) NSArray *dataList;
- (IBAction)didClickPicker:(id)sender;

@property (nonatomic, strong)UIPickerView *colorPickerView;
@property (nonatomic, strong)NSArray *colorList;
@end

