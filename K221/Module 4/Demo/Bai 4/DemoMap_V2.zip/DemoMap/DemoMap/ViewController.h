//
//  ViewController.h
//  DemoMap
//
//  Created by TNKHANH on 7/18/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
//#import <CoreLocation/CoreLocation.h>
@interface ViewController : UIViewController<MKMapViewDelegate, CLLocationManagerDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;

//Bien quan ly truy xuat vi tri nguoi dung
@property (nonatomic)CLLocationManager *locationManager;

//IBAction
- (IBAction)selectMapType:(id)sender;
- (IBAction)myLocation:(id)sender;
@end

