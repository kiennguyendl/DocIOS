//
//  ViewController.m
//  DemoMap
//
//  Created by TNKHANH on 7/18/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //set location manager va mapkit de lay vi tri nguoi dung
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    self.mapView.delegate = self;
    
    //Xin quyen truy cap vi tri nguoi dung
    if ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
        [self.locationManager requestAlwaysAuthorization];
    }
    //Hien thi vi tri nguoi dung tren ban do
    //self.mapView.showsUserLocation = true;
    //Them gesture cho mapview
    [self addGestureToMapView:self.mapView];
    [self showT3HOnMap];
}
-(void)showT3HOnMap{
    CLLocationCoordinate2D t3Hlocation = CLLocationCoordinate2DMake(10.7711033,106.6728748);
    //Tao region quanh vi tri nguoi dung tren mapview
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(t3Hlocation, 2000, 2000);//meters
    //Thiet lap region cho mapview
    [self.mapView setRegion:region];
    
    //Them annotation
    [self addAnnotationWithLocation:t3Hlocation];
}
//1. Lay location cua nguoi dung va zoom toi
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    //Tao region quanh vi tri nguoi dung tren mapview
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 2000, 2000);//meters
    //Thiet lap region cho mapview
    [self.mapView setRegion:region];
    
    //Them annotation
    [self addAnnotationWithLocation:userLocation.coordinate];
}
//Them Annotation len user location
-(void) addAnnotationWithLocation:(CLLocationCoordinate2D)coordinate{
    //Khoi tao Annotation
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    //Thiet lap coordinate cho annotation
    point.coordinate = coordinate;
    //Thiet lap cac thuoc tinh khac
    point.title = [NSString stringWithFormat:@"%f",coordinate.latitude];
    point.subtitle = [NSString stringWithFormat:@"%f",coordinate.longitude];
    //Them annotation len mapview
    [self.mapView addAnnotation:point];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//2. Thiet lap map type cho mapview
- (IBAction)selectMapType:(id)sender {
    //Tao alert controller style action sheet
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:@"Choose type" preferredStyle:UIAlertControllerStyleActionSheet];
    //Them cac alert action
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action){}];
    //Standard choice
    UIAlertAction *standardAction = [UIAlertAction actionWithTitle:@"Standard" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        self.mapView.mapType = MKMapTypeStandard;
    }];
    //Satelitte choice
    UIAlertAction *satelliteAction = [UIAlertAction actionWithTitle:@"Satellite" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        self.mapView.mapType = MKMapTypeSatellite;
    }];
    //Hybrid choice
    UIAlertAction *hybridAction = [UIAlertAction actionWithTitle:@"Hybrid" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        self.mapView.mapType = MKMapTypeHybrid;
    }];
    
    
    [alert addAction:standardAction];
    [alert addAction:satelliteAction];
    [alert addAction:hybridAction];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:true completion:nil];
}
//3. Ve vi tri hien tai tren map
- (IBAction)myLocation:(id)sender {
    [self.locationManager startUpdatingLocation];
}
//3.1 Phuong thuc delegate cuar CLLocationManager
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    [self setLocation:newLocation];
    [self.locationManager stopUpdatingLocation];
}
//3.2 Ham tu dinh nghia, cap nhat vi tri hien tai
-(void)setLocation:(CLLocation*)location{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(location.coordinate, 2000, 2000);
    [self.mapView setRegion:region animated:true];
}

//4. Them gesture len map view
-(void)addGestureToMapView:(MKMapView *)mapView{
    //Tao gesture long press
    UILongPressGestureRecognizer *gesture = [[UILongPressGestureRecognizer alloc] init];
    gesture.minimumPressDuration = 1;
    //Xu ly su kien cho gesture
    [gesture addTarget:self action:@selector(addAnnotationWithGesture:)];
    
    //Them gesture len mapview
    [mapView addGestureRecognizer:gesture];
    
}
//4.1 Them annotation khi gap su kien long press
-(void)addAnnotationWithGesture:(UIGestureRecognizer *)gesture{
    //Xoa cac annotation hien co
    [self.mapView removeAnnotations:self.mapView.annotations];
    
    //Lay vi tri diem cham tren man hinh
    CGPoint touchPoint = [gesture locationInView:self.mapView];
    //Chuyen doi vi tri tren man hinh -> location tren map
    CLLocationCoordinate2D locationOnMap = [self.mapView convertPoint:touchPoint toCoordinateFromView:self.mapView];
    //Them annotaion cho vi tri nay
    [self addAnnotationWithLocation:locationOnMap];
    
}
@end
