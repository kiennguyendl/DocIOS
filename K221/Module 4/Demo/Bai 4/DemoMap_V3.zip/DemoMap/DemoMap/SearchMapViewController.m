//
//  SearchMapViewController.m
//  DemoMap
//
//  Created by TNKHANH on 7/22/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "SearchMapViewController.h"
#import "ViewController.h"
@interface SearchMapViewController ()

@end

@implementation SearchMapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configSearchController];
    
}
-(void)viewWillAppear:(BOOL)animated{
    
    self.searchController.searchBar.hidden = false;
}
//Cau hinh search controller
-(void)configSearchController{
    //Khoi tao search controller
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    
    self.searchController.searchResultsUpdater = self;
    
    //Config search controller
    self.searchController.dimsBackgroundDuringPresentation = false;
    self.searchController.hidesNavigationBarDuringPresentation = false;
    self.searchController.searchBar.placeholder = @"Enter an address";
    self.searchController.searchBar.returnKeyType = UIReturnKeySearch;
    
    //Uy thac cho search bar
    self.searchController.searchBar.delegate = self;
    [self.searchController.searchBar sizeToFit];
    
    //Them search controller tren header cua table view
    self.tableView.tableHeaderView = self.searchController.searchBar;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.isSearching) {
        return self.searchResult.count;
        //return 1;
    }
    return 0;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }
    
    if (self.isSearching) {//Dang tim kiem dia diem
        NSDictionary *item = self.searchResult[indexPath.row];
        
        cell.textLabel.text = [item objectForKey:@"formatted_address"];
    }
    else{
        cell = nil;
    }
    
    return cell;
}
#pragma mark - Table View delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isSearching) {
        //Init view
        ViewController *mapView = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
        //Pass data
        NSDictionary *currentItem  = self.searchResult[indexPath.row];
        mapView.currentItem = currentItem;
        //handle search
        [self.searchController.searchBar resignFirstResponder];
        self.searchController.searchBar.hidden = true;
        //Push view
        [self.navigationController pushViewController:mapView animated:true];
        
    }
}

#pragma mark - UISearchResult Updating
-(void)updateSearchResultsForSearchController:(UISearchController *)searchController{
    self.searchResult = [[NSMutableArray alloc] init];
    NSString *searchString = searchController.searchBar.text;
    NSString *urlString = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/geocode/json?address=%@&key=AIzaSyB6hMP_g-qQo6YmTFxi4NB3vF8oHE3Iv9I",searchString];
    //Add percent encoding
    urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    //Tao url request
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    //Su dung NSURL session de lay data
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config];
    
    NSURLSessionTask *task = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData *data,NSURLResponse *response, NSError *error){
        if(!error){
            NSDictionary *myDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error: nil];
            
            NSArray *result = [myDict objectForKey:@"results"];
            //NSLog(@"%@",result);
            for (NSDictionary *item in result) {
                //NSLog(@"%@",[place objectForKey:@"formatted_address"]);
                [self.searchResult addObject:item];

            }
            //Reload table view trong main thread
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }
    
    }];
    
    [task resume];
    
    
}

#pragma mark - UISearchbar delegate
-(void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    
    self.isSearching = true;
}
-(void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    //self.isSearching = false;
    
    //[self.tableView reloadData];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    NSLog(@"search");
    //[self.searchController.searchBar resignFirstResponder];
    self.isSearching = true;
    [self.tableView reloadData];

    return true;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
