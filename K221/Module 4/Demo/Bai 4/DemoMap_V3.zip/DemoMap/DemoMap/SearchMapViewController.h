//
//  SearchMapViewController.h
//  DemoMap
//
//  Created by TNKHANH on 7/22/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchMapViewController : UITableViewController<UISearchBarDelegate,UISearchResultsUpdating,UITextFieldDelegate>
@property (nonatomic)UISearchController *searchController;
@property (nonatomic)NSMutableArray *searchResult;
@property BOOL isSearching;
@end
