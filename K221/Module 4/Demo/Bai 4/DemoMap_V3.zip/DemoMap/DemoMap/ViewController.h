//
//  ViewController.h
//  DemoMap
//
//  Created by TNKHANH on 3/13/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
@interface ViewController : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;

- (IBAction)selectTypes:(id)sender;
- (IBAction)myLocation:(id)sender;
//Khai bao bien quan ly viec truy xuat vi tri cua nguoi dung
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong)NSString *address;
//Khai bao dia diem hien tai
@property (nonatomic)NSDictionary *currentItem;
@end

