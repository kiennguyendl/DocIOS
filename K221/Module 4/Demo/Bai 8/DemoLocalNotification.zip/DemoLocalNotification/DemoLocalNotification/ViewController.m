//
//  ViewController.m
//  DemoLocalNotification
//
//  Created by TNKHANH on 8/1/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "ViewController.h"
#import "CreateScheduleViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Dang ky notification center de nhan thong diep
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadTable) name:@"reloadData" object:nil];
}
-(void)reloadTable{
    [self.tableView reloadData];
}
-(void)viewWillAppear:(BOOL)animated{
    [self.tableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Table View DataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [[[UIApplication sharedApplication] scheduledLocalNotifications] count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId   ] ;
    }
    //Config cell
    UILocalNotification *item = [[UIApplication sharedApplication] scheduledLocalNotifications][indexPath.row];
    cell.textLabel.text = item.alertBody;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd-MM-yyyy HH:mm"];
    cell.detailTextLabel.text = [formatter stringFromDate:item.fireDate];
    
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CreateScheduleViewController *detailview = [self.storyboard instantiateViewControllerWithIdentifier:@"CreateScheduleViewController"];
    UILocalNotification *currentNotification = [[UIApplication sharedApplication] scheduledLocalNotifications][indexPath.row];
    
    detailview.currentNotification = currentNotification;
    
    [self.navigationController pushViewController:detailview animated:true];
    
}
@end
