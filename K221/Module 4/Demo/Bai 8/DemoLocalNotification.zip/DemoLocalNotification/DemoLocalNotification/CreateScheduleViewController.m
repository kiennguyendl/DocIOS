//
//  CreateScheduleViewController.m
//  DemoLocalNotification
//
//  Created by TNKHANH on 8/1/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "CreateScheduleViewController.h"

@interface CreateScheduleViewController ()

@end

@implementation CreateScheduleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.currentNotification) {
        //Update UI
        self.title = @"Edit schedule";
        self.txtContent.text = self.currentNotification.alertBody;
        self.datePicker.date = self.currentNotification.fireDate;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)save:(id)sender {
    //Dau ban phim
    [self.txtContent resignFirstResponder];
    //Lay ngay duoc thiet lap tren datePicker
    NSDate *fireDate = [self.datePicker date];
    
    //Tao va lap lich cho notification
    UILocalNotification *localNotification = [[UILocalNotification alloc] init];
    
    localNotification.fireDate = fireDate;
    localNotification.alertBody = self.txtContent.text;
    localNotification.timeZone = [NSTimeZone defaultTimeZone];
    localNotification.soundName = @"";
    localNotification.applicationIconBadgeNumber = [[UIApplication sharedApplication] applicationIconBadgeNumber] + 1;
    //Cancel current notification
    if (self.currentNotification) {
        [[UIApplication sharedApplication] cancelLocalNotification:self.currentNotification];
    }
    
    //Dang ky local notification
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    
    [self.navigationController popViewControllerAnimated:true];
    
    
    
    
    
}
@end
