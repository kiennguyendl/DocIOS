//
//  CreateScheduleViewController.h
//  DemoLocalNotification
//
//  Created by TNKHANH on 8/1/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateScheduleViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtContent;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
- (IBAction)save:(id)sender;
@property (nonatomic)UILocalNotification *currentNotification;

@end
