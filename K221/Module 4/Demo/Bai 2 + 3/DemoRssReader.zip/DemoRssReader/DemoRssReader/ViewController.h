//
//  ViewController.h
//  DemoRssReader
//
//  Created by TNKHANH on 7/11/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Item.h"
@interface ViewController : UIViewController<NSXMLParserDelegate,UITableViewDataSource,UITableViewDelegate>
@property (nonatomic)NSMutableArray *itemList;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic)NSString *currentElement;

@property (nonatomic)Item *myItem;
@end

