//
//  Item.m
//  DemoRssReader
//
//  Created by TNKHANH on 7/11/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "Item.h"

@implementation Item
@synthesize description;
@end
