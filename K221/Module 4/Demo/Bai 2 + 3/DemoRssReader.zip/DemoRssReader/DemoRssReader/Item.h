//
//  Item.h
//  DemoRssReader
//
//  Created by TNKHANH on 7/11/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Item : NSObject
@property NSMutableString *title;
@property NSMutableString *link;
@property NSMutableString *pubDate;
@property NSMutableString *description;
@end
