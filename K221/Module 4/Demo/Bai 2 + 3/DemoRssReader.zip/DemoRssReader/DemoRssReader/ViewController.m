//
//  ViewController.m
//  DemoRssReader
//
//  Created by TNKHANH on 7/11/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"
#import "NewsItemCell.h"
#define kUrlString @"http://images.apple.com/main/rss/hotnews/hotnews.rss"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)getData{
    self.itemList = [[NSMutableArray alloc] init];
    
    NSString *urlString = [kUrlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    //Parse XML
    [self parseXML:urlString];
}
-(void)parseXML:(NSString *)urlString{
    //Khoi tao url tu string
    NSURL *url = [NSURL URLWithString:urlString];
    
    //Tao parser de parse xml
    NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:url];
    
    //Uy thac cho view controller
    parser.delegate = self;
    //Parse
    [parser parse];
    
}

//Start Element - Duoc thuc hien khi phat hien dau mo the
-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict{
    self.currentElement = elementName;
    if ([elementName isEqualToString:@"item"]) {
        //Khi phat hien dau mo the item thi tao moi item
        self.myItem = [Item new];
        self.myItem.title = [[NSMutableString alloc] init];
        self.myItem.link = [[NSMutableString alloc] init];
        self.myItem.pubDate = [[NSMutableString alloc] init];
        self.myItem.description = [[NSMutableString alloc] init];
    }
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    if (self.myItem) {
        if ([self.currentElement isEqualToString:@"title"]) {
            [self.myItem.title appendString:string];
        }
        if ([self.currentElement isEqualToString:@"link"]) {
            [self.myItem.link appendString:string];
        }
        if ([self.currentElement isEqualToString:@"pubDate"]) {
            [self.myItem.pubDate appendString:string];
        }
        if ([self.currentElement isEqualToString:@"description"]) {
            [self.myItem.description appendString:string];
        }
    }
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
    if ([elementName isEqualToString:@"item"]) {
        [self.itemList addObject:self.myItem];
    }
}
#pragma mark - Table View Data Source
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.itemList.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //Init cell
    NSString *cellId = @"Cell";
    NewsItemCell  *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    //Config cell
    Item *currentItem = self.itemList[indexPath.row];
    cell.lblTitle.text = currentItem.title;
    cell.lblPubDate.text = currentItem.pubDate;
    cell.lblDescription.text = currentItem.description;
    
    //accessory
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}
@end
