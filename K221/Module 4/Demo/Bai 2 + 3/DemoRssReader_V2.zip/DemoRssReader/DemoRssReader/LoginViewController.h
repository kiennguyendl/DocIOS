//
//  LoginViewController.h
//  DemoRssReader
//
//  Created by TNKHANH on 7/15/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonDigest.h>
@interface LoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtUsername;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
- (IBAction)login:(id)sender;

@end
