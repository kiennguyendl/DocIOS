//
//  LoginViewController.m
//  DemoRssReader
//
//  Created by TNKHANH on 7/15/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "LoginViewController.h"
#import "ViewController.h"
#define kUrlString @"http://113.161.116.175/abc/iOSWSLogin.php"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)login:(id)sender {
    /*
    ViewController *rssView = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:rssView];
    
    [self presentViewController:navigationController animated:true completion:nil];
     */
    [self sendDataWithMethod:@"POST"];
}
-(void)sendDataWithMethod:(NSString *)method{
    //GET || POST
    NSString *urlString = [NSString stringWithFormat:@"%@?username=%@&password=%@",kUrlString,self.txtUsername.text,self.txtPassword.text];

    
    urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSMutableURLRequest *urlRequest = nil;
    NSURL *url = nil;
    
    if ([method isEqualToString:@"GET"]) {//Phuong thuc GET
        url = [NSURL URLWithString:urlString];
        urlRequest = [NSMutableURLRequest requestWithURL:url];
    }
    else{//POST
        NSString *param = [NSString stringWithFormat:@"username=%@&password=%@",self.txtUsername.text,self.txtPassword.text];
        NSString *postLength = [NSString stringWithFormat:@"%lu",(unsigned long)[param length]];
        NSData *paramData = [param dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:true];
        url = [NSURL URLWithString:kUrlString];
        urlRequest = [NSMutableURLRequest requestWithURL:url];
        [urlRequest setValue:postLength forHTTPHeaderField:@"Content-Length"];
        [urlRequest setHTTPBody:paramData];
    }
    
    //Thiet lap phuong thuc gui data cho urlRequest
    [urlRequest setHTTPMethod:method];
    
    //Thuc hien ket noi den server su dung NSUrlSession
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *urlSession = [NSURLSession sessionWithConfiguration:config];
    
    NSURLSessionTask *task = [urlSession dataTaskWithRequest:urlRequest completionHandler:^(NSData *data,NSURLResponse *response, NSError *error){
        if (!error) {
            //Serialize Json
            NSDictionary *result = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
            NSString *status = result[@"result"];
            if ([status isEqualToString:@"OK"]) {
                //Present Rss View
                ViewController *rssView = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
                UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:rssView];
                
                [self presentViewController:navigationController animated:true completion:nil];
            }
            else{
                NSLog(@"Incorrect username or password");
            }

        }
    
    }];
    [task resume];
    
    //An ban phim
    [self.txtUsername resignFirstResponder];
    [self.txtPassword resignFirstResponder];
    
}
@end
