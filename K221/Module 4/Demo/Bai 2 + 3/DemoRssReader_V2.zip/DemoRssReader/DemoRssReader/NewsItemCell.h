//
//  NewsItemCell.h
//  DemoRssReader
//
//  Created by TNKHANH on 7/11/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsItemCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblPubDate;
@property (weak, nonatomic) IBOutlet UILabel *lblDescription;

@end
