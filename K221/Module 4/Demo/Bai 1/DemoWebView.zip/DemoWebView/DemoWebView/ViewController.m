//
//  ViewController.m
//  DemoWebView
//
//  Created by TNKHANH on 6/24/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"
#import "Reachability.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Kiem tra thiet bi co ket noi Internet hay khong
    [self checkNetworkConnection];
    //Tai url cho web view
//    NSString *urlString = @"http://t3h.vn";
//    [self loadWebView:self.webView withUrlString:urlString];
    
    //Tai document cho webview
    //[self loadWebView:self.webView withDocument:@"a" type:@"html"];
    
    //Scale page webview
    self.webView.scalesPageToFit = true;
    
    //Uy thac webview
    self.webView.delegate = self;
    
    //An indicator view
    self.indicatorView.hidden = true;
    self.indicatorView.hidesWhenStopped = true;
}
//Kiem tra ket noi Internet
-(void)checkNetworkConnection{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    if (networkStatus == ReachableViaWWAN) {
        NSLog(@"Co ket noi 3G");
    }
    else if (networkStatus == ReachableViaWiFi){
        NSLog(@"Co ket noi Wifi");
    }
    else if (networkStatus == NotReachable){
        NSLog(@"Khong co ket noi internet");
    }
}

//Hien thi noi dung mot url len webview
-(void)loadWebView:(UIWebView *)webView withUrlString:(NSString *)urlString{
    //Khoi tao doi tuong url
    NSURL *url = [NSURL URLWithString:urlString];
    //Khoi tao doi tuong request
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    //Load request cho web view
    [webView loadRequest:urlRequest];
}

//Hien thi document len webview
-(void)loadWebView:(UIWebView *)webView withDocument:(NSString *)name type:(NSString *)type{
    //Lay file path trong bundle
    NSString *filePath = [[NSBundle mainBundle] pathForResource:name ofType:type];
    //Tao url tu filePath
    NSURL *url = [NSURL fileURLWithPath:filePath];
    //Khoi tao doi tuong request
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    //Load request cho web view
    [webView loadRequest:urlRequest];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Cap nhat lai thanh dia chi sau khi load webview
-(void)updateWebAddress{
    //Lay url hien tai cua web view
    NSURL *url = [self.webView.request mainDocumentURL];
    //Cap nhat web address
    self.txtAddress.text = [url absoluteString];
}
//Cap nhat web title
-(void)updateWebTitle{
    self.lblWebTitle.text = [self.webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    
}
- (IBAction)goToPage:(id)sender {
    
    NSString *urlString = self.txtAddress.text;
    NSString *prefixStr = @"http://";
    if (![urlString hasPrefix:prefixStr]) {
        urlString = [prefixStr stringByAppendingString:urlString];
    }
    
    [self loadWebView:self.webView withUrlString:urlString];
    
    //An ban phim
    [self.txtAddress resignFirstResponder];
}
#pragma mark Web view delegate
-(void)webViewDidStartLoad:(UIWebView *)webView{
    NSLog(@"Start");
    [self updateWebAddress];
    self.indicatorView.hidden = false;
    [self.indicatorView startAnimating];
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    NSLog(@"Finish");
    [self updateWebTitle];
    [self.indicatorView stopAnimating];
}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    NSLog(@"%@",[error localizedDescription]);
}

@end
