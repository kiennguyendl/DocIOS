//
//  Webpage.m
//  DemoWebView
//
//  Created by TNKHANH on 6/27/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "Webpage.h"
#define kWebTitleKey @"title"
#define kWebAddressKey @"address"
@implementation Webpage
-(id)initWithTitle:(NSString *)title andAddress:(NSString *)address{
    self.webTitle = title;
    self.webAddress = address;
    
    return self;
}
-(id)initWithCoder:(NSCoder *)decoder{
    if (self == [super init]) {
        self.webTitle = [decoder decodeObjectForKey:kWebTitleKey];
        self.webAddress = [decoder decodeObjectForKey:kWebAddressKey];
    }
    return self;
}
-(void)encodeWithCoder:(NSCoder *)encoder{
    [encoder encodeObject:self.webTitle forKey:kWebTitleKey];
    [encoder encodeObject:self.webAddress forKey:kWebAddressKey];
}
@end
