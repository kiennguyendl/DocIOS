//
//  HistoryViewController.h
//  DemoWebView
//
//  Created by TNKHANH on 6/27/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Webpage.h"
//Protocol
@protocol HistoryViewDelegate

-(void)goToWebpage:(Webpage *)webPage;
@end

@interface HistoryViewController : UITableViewController
@property (nonatomic)NSMutableArray *historyList;
@property (nonatomic, strong)id delegate;
@end
