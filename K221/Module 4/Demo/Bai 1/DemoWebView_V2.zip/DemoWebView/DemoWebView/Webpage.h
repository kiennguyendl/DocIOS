//
//  Webpage.h
//  DemoWebView
//
//  Created by TNKHANH on 6/27/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Webpage : NSObject
@property (nonatomic)NSString *webTitle;
@property (nonatomic)NSString *webAddress;

//Phuong thuc khoi tao
-(id)initWithTitle:(NSString *)title andAddress:(NSString *)address;
@end
