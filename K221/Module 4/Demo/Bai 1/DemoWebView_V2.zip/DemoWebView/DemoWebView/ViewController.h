//
//  ViewController.h
//  DemoWebView
//
//  Created by TNKHANH on 6/24/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Webpage.h"
#import "HistoryViewController.h"
@interface ViewController : UIViewController<UIWebViewDelegate,HistoryViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;
- (IBAction)goToPage:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblWebTitle;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indicatorView;
@property (nonatomic)NSMutableArray *historyList;

@end

