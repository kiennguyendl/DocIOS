//
//  ViewController.m
//  DemoGallery
//
//  Created by TNKHANH on 7/29/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSString *filePath = [self getFilePathInDocumentWithName:@"demoImg.jpg"];
    //Lay hinh anh theo duong dan trong ung dung
    UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfFile:filePath]];
    
    self.imageView.image = image;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)saveImage:(id)sender {
    if (self.imageView.image) {
        //Luu hinh vao saved photos album
        UIImageWriteToSavedPhotosAlbum(self.imageView.image, self, nil, nil);
        //Luu hinh xuong thu muc Document cua ung dung
        [self saveImageToDocument:self.imageView.image];
    }
}
//Luu hinh xuong thu muc Document cua ung dung
-(void)saveImageToDocument:(UIImage *)image{
    //Chuan bi data
    NSData *jpgData = UIImageJPEGRepresentation(image, 1.0);
    //Tao duong dan hinh trong document
    NSString *filePath = [self getFilePathInDocumentWithName:@"demoImg.jpg"];
    NSLog(@"%@",filePath);
    //Ghi file
    if([jpgData writeToFile:filePath atomically:true]){
        //Save thanh cong
        NSLog(@"Saved to Documents");
    }
    else{
        NSLog(@"Something went wrong");
    }
}
//Lay duong dan cua file trong thu muc document
-(NSString *)getFilePathInDocumentWithName:(NSString *)fileName{
    return [NSHomeDirectory() stringByAppendingString:[NSString stringWithFormat:@"/Documents/%@",fileName]];
}

- (IBAction)chooseSource:(id)sender {
    //Tao alert controller
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:@"Choose Source" preferredStyle:UIAlertControllerStyleActionSheet];
    
    //Tao va them cac action vao alert
    UIAlertAction *cameraAction = [UIAlertAction actionWithTitle:@"Camera" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        //Kiem tra source type camera co ton tai khong
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            [self showImagePickerWithSourceType:UIImagePickerControllerSourceTypeCamera];
        }
        else{
            NSLog(@"Camera not found");
        }
    }];
    
    UIAlertAction *photoLibraryAction = [UIAlertAction actionWithTitle:@"Photos Library" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self showImagePickerWithSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    }];
    UIAlertAction *savePhotoAction = [UIAlertAction actionWithTitle:@"Saved Photos album" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self showImagePickerWithSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action){
        
    }];
    
    [alert addAction:cameraAction];
    [alert addAction:photoLibraryAction];
    [alert addAction:savePhotoAction];
    [alert addAction:cancelAction];
    
    //Them alert vao view
    [self presentViewController:alert animated:true completion:nil];
    
}
//Hien thi image picker controller voi source type tuong ung
-(void)showImagePickerWithSourceType:(UIImagePickerControllerSourceType)sourceType{
    //Khoi tao image picker
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    //Thiet lap delegate
    picker.delegate = self;
    //Thiet lap source type
    picker.sourceType = sourceType;
    //Cho phep chinh sua
    picker.allowsEditing = true;
    
    //Hien thi image picker
    [self presentViewController:picker animated:true completion:nil];
}


#pragma mark Image Picker delegate
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    NSLog(@"%@",info);
    UIImage *originalImage = info[UIImagePickerControllerOriginalImage];
                              
    UIImage *editedImage = info[UIImagePickerControllerEditedImage];
    //Cap nhat UI
    self.imageView.image = editedImage;
    [self dismissViewControllerAnimated:true completion:nil];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    NSLog(@"Canceled");
    [self dismissViewControllerAnimated:true completion:nil];
}


@end
