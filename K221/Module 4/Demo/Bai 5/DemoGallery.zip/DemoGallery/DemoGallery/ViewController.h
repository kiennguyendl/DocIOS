//
//  ViewController.h
//  DemoGallery
//
//  Created by TNKHANH on 7/29/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
- (IBAction)saveImage:(id)sender;

- (IBAction)chooseSource:(id)sender;

@end

