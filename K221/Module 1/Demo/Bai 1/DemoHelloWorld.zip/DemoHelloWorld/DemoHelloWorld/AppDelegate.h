//
//  AppDelegate.h
//  DemoHelloWorld
//
//  Created by TNKHANH on 2/29/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

