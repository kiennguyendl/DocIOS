//
//  NewViewController.h
//  Demo_Mod1_Bai5
//
//  Created by TNKHANH on 3/18/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtA;
@property (weak, nonatomic) IBOutlet UITextField *txtB;
@property (weak, nonatomic) IBOutlet UITextField *txtC;
@property (weak, nonatomic) IBOutlet UILabel *lblResult;
- (IBAction)didSolve:(id)sender;

@end
