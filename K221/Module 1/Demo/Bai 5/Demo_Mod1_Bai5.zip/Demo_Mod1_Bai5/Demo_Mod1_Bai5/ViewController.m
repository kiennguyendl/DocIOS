//
//  ViewController.m
//  Demo_Mod1_Bai5
//
//  Created by TNKHANH on 3/18/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //self.lblMessage.text = @"Xin chao!";
    UILabel *myLabel = (UILabel *)[self.view viewWithTag:10];
    myLabel.text = @"label get by tag";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)didClick:(id)sender {
    //self.lblMessage.text = @"Click me";
    //Casting tu id->UIButton
    UIButton *myButton = (UIButton *)sender;
    //self.lblMessage.text = myButton.titleLabel.text;
    self.lblMessage.text  = self.txtContent.text;
    //Doi mau label
    self.lblMessage.textColor = [UIColor redColor];
    //An ban phim
    [self.txtContent resignFirstResponder];
}
@end
