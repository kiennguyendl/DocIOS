//
//  NewViewController.m
//  Demo_Mod1_Bai5
//
//  Created by TNKHANH on 3/18/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "NewViewController.h"

@interface NewViewController ()

@end

@implementation NewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)didSolve:(id)sender {
    //Chuyen tu NSString -> float
    float a = [self.txtA.text floatValue];
    float b = [self.txtB.text floatValue];
    float c = [self.txtC.text floatValue];
    //Goi ham giai phuong trinh bac 2
    self.lblResult.text = [self giaiPTBac2:a vaB:b vaC:c];
    
    //Thiet lap so dong hien thi cho label
    self.lblResult.numberOfLines = 0;
    [self.lblResult sizeToFit];
}

//Ham giai Phuong trinh bac 2
-(NSString *)giaiPTBac2:(float) a vaB:(float)b vaC:(float)c{
    float x,x1,x2;
    if (a == 0 && b== 0 & c == 0) {
        return @"PT Vo so nghiem";
    }
    else if (a == 0 && b== 0) {
        return @"PT Vo nghiem";
    }
    else if(a == 0) {
        x = -c/b;
        return [NSString stringWithFormat:@"PT co nghiem don x= %.2f",x];
    }
    else{
        float delta = b*b-4*a*c;
        if (delta < 0) {
            return @"PT Vo nghiem";
        }
        else if(delta == 0){
            x = -b/(2*a);
            return [NSString stringWithFormat:@"PT co nghiem kep x= %.2f",x];
        }
        else{
            x1 = (-b-sqrt(delta))/(2*a);
            x2 = (-b+sqrt(delta))/(2*a);
            return [NSString stringWithFormat:@"PT co 2 nghiem phan biet x1 = %.2f, x2 = %.2f",x1,x2];
        }
    }
    return @"";
    
    
}
@end
