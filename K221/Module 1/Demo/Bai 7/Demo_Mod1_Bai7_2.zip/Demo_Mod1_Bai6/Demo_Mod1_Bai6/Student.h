//
//  Student.h
//  Demo_Mod1_Bai6
//
//  Created by TNKHANH on 3/21/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject
@property (nonatomic, strong)NSString *code;
@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString *phone;
@property (nonatomic)NSInteger age;
@property (nonatomic, strong)NSString *gender;
@property (nonatomic)float mark;
@property (nonatomic,strong) NSString *info;
@property (nonatomic)BOOL isPoor;
@end
