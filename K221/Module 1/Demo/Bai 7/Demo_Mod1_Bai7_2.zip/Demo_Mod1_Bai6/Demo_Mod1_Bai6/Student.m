//
//  Student.m
//  Demo_Mod1_Bai6
//
//  Created by TNKHANH on 3/21/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "Student.h"

@implementation Student
-(instancetype)init{
    static int studentId = 1;
    self.code = [NSString stringWithFormat:@"SV%04d",studentId];
    studentId++;
    return self;
}
@end
