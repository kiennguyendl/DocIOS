//
//  ViewController.m
//  Demo_Mod1_Bai6
//
//  Created by TNKHANH on 3/21/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "ViewController.h"
#import "Student.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.txtName.delegate = self;
    
    //Khoi tao mang StudentList de them Student
    self.studentList = [[NSMutableArray alloc] init];
    hashTable1 = [NSHashTable hashTableWithOptions:NSHashTableWeakMemory];
    [hashTable1 addObject:@"Class 1"];
    //Mac dinh, sinh vien khong phai la ho ngheo
    [self.swIsPoor setOn:false];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)sliderDidChange:(UISlider *)sender {
    self.lblAge.text = [NSString stringWithFormat:@"%.0f", sender.value];
}
- (IBAction)segmentDidChange:(UISegmentedControl *)sender {
  
}

- (IBAction)stepperDidChange:(UIStepper *)sender {
    self.lblMark.text = [NSString stringWithFormat:@"%.2f",sender.value];
}



- (IBAction)addStudent:(id)sender {
    /*
    //Khoi tao Student
    Student *theStudent = [[Student alloc] init];
    //Set cac thuoc tinh cho doi tuong voi cac gia tri cua cac control tren man hinh
    theStudent.name = self.txtName.text;
    theStudent.phone = self.txtPhone.text;
    theStudent.age = [self.lblAge.text integerValue];
    theStudent.gender = self.smGender.selectedSegmentIndex == 0 ? @"Nam" : @"Nu";
    theStudent.mark = [self.lblMark.text floatValue];
    theStudent.info = self.tvInfo.text;
    theStudent.isPoor = self.swIsPoor.isOn;
    
    //Them sinh vien vua tao vao studentList
    [self.studentList addObject:theStudent];
    
    [self.sliderAge setValue:self.sliderAge.minimumValue animated:true];
     */
    [self addStudentWithDictionary];
}
-(void)addStudentWithDictionary{
    //Khoi tao Dictionary Student
    NSMutableDictionary *student = [[NSMutableDictionary alloc] init];
    //set value cho cac thuoc tinh
    static int sID = 1;
    NSString *studentId = [NSString stringWithFormat:@"%04d",sID];
    sID++;
    [student setObject:studentId forKey:@"ID"];
    [student setObject:self.txtName.text forKey:@"name"];
    [student setObject:self.txtPhone.text forKey:@"phone"];
    [student setObject:self.lblAge.text forKey:@"age"];
    self.smGender.selectedSegmentIndex == 0 ?
    [student setObject:@"Nam" forKey:@"gender"] :
    [student setObject:@"Nu" forKey:@"gender"];
    
    [student setObject:self.lblMark.text forKey:@"mark"];
    [student setObject:self.tvInfo.text forKey:@"info"];
    [student setObject:[NSNumber numberWithBool:self.swIsPoor.isOn]  forKey:@"isPoor"];
    //Them Student vao StudentList
    [self.studentList addObject:student];
}
- (IBAction)printListStudent:(id)sender {
    /*for (Student *theStudent in self.studentList) {
        //In thong tin 1 sinh vien
        NSLog(@"Ten: %@",theStudent.name);
        NSLog(@"Dien thoai: %@",theStudent.phone);
        NSLog(@"Tuoi: %ld",theStudent.age);
        NSLog(@"Gioi tinh: %@",theStudent.gender);
        NSLog(@"Diem: %.2f",theStudent.mark);
        NSLog(@"Gioi thieu: %@",theStudent.info);
        NSString *isPoor = theStudent.isPoor ? @"Co" : @"Khong";
        NSLog(@"Ho ngheo: %@",isPoor);
        NSLog(@"--------------------");
        
    }*/
    
    [self printListStudentDictionary];
    
}
-(void)printListStudentDictionary{
    NSLog(@"Danh sach sinh vien");
    NSLog(@"----------------");
    for (NSDictionary *myStudent in self.studentList) {
        NSLog(@"Ma SV: %@",[myStudent objectForKey:@"ID"]);
        NSLog(@"Ho ten: %@",[myStudent objectForKey:@"name"]);
        NSLog(@"Dien thoai: %@",[myStudent objectForKey:@"phone"]);
        NSLog(@"Tuoi: %@",[myStudent objectForKey:@"age"]);
        NSLog(@"Gioi tinh: %@",[myStudent objectForKey:@"gender"]);
        NSLog(@"Diem: %@",[myStudent objectForKey:@"mark"]);
        NSLog(@"Gioi thieu: %@",[myStudent objectForKey:@"info"]);
        bool hoNgheo = [[myStudent objectForKey:@"isPoor"] boolValue];
        hoNgheo == true ? NSLog(@"Ho ngheo: Co"):NSLog(@"Ho ngheo: Khong");
        NSLog(@"-------/------");
    }
}
//Ghi nhan su kien touch len man hinh
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.txtName resignFirstResponder];
    [self.tvInfo resignFirstResponder];
    [self.txtPhone resignFirstResponder];
}
#pragma mark UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    //An ban phim
    [textField resignFirstResponder];
    
    return true;
}
#pragma mark UITextViewDelegate
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        //An ban phim
        [textView resignFirstResponder];
    }
    return true;
}
@end
