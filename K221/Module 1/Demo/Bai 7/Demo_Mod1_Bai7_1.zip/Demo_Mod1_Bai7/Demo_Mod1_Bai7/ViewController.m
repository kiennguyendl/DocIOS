//
//  ViewController.m
//  Demo_Mod1_Bai7
//
//  Created by TNKHANH on 3/25/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
bool isShow;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self workingWithDictionary];
    //Them cac control len man hinh
    [self addCustomControl];
    
}
//Lam viec voi NSDictionary
-(void)workingWithDictionary{
    //Phan tu 1
    NSString *key1 = @"name";
    NSString *obj1 = @"T3H";
    //Phan tu 2
    NSString *key2 = @"age";
    NSNumber *obj2 = @12;
    
    //Dict1
    NSDictionary *dict1 = @{key1:obj1,key2:obj2};
    //Dict2
    NSDictionary *dict2 = [[NSDictionary alloc] initWithObjectsAndKeys:obj1,key1,obj2,key2, nil];
    NSLog(@"Dict 1: %@",dict1);
    NSLog(@"Dict 2: %@",dict2);
    
    //Dict3
    NSMutableDictionary *dict3 = [NSMutableDictionary dictionaryWithDictionary:dict2];
    //Them phan tu
    [dict3 setObject:@"Ho Chi Minh" forKey:@"city"];
    //Cap nhat phan tu
    [dict3 setObject:@"KHTN" forKey:@"name"];
    
    
    NSArray *arr1 = @[@1,@2,@3];
    [dict3 setObject:arr1 forKey:@"order"];
    NSLog(@"Dict 3: %@",dict3);
    
    //Truy xuat Dictionary
    NSString *city = [dict3 objectForKey:@"city"];
    NSLog(@"City %@",city);
    
    id arr = [dict3 objectForKey:@"order"];
    NSLog(@"%@", arr);
    
    //Truy xuat tat ca cac key
    NSLog(@"All keys: %@",[dict3 allKeys]);
    //Truy xuat tat ca cac value
    NSLog(@"All values: %@",[dict3 allValues]);
    
    //Xoa mot hoac nhieu phan tu
    [dict3 removeObjectForKey:@"order"];
    [dict3 removeObjectsForKeys:@[@"name",@"city"]];
    NSLog(@"Dict 3: %@",dict3);
    
    //Xoa tat ca
    [dict3 removeAllObjects];
}

//Them cac control len view
-(void)addCustomControl{
    //LABEL
    //Khoi tao label
    CGRect labelFrame = CGRectMake(self.view.frame.size.width/2 - 100, self.view.frame.size.height/2-25, 200, 50);
    
    UILabel *myLabel = [[UILabel alloc] initWithFrame:labelFrame];
    //Thiet lap tag
    myLabel.tag = 10;
    //Thiet lap noi dung
    myLabel.text = @"Hello Everyone";
    //Color
    myLabel.textColor = [UIColor orangeColor];
    //Alignment
    myLabel.textAlignment = NSTextAlignmentCenter;
    //Background Color
    myLabel.backgroundColor = [UIColor lightGrayColor];
    //Border
    myLabel.layer.borderColor = [[UIColor redColor] CGColor];
    myLabel.layer.borderWidth = 1.0;
    //Them control vao view
    [self.view addSubview:myLabel];
    
    
    //BUTTON
    //Khoi tao custom button
    UIButton *myButton = [UIButton buttonWithType:UIButtonTypeCustom];
    //Thiet lap frame
    [myButton setFrame:CGRectMake(60, 100, 200, 40)];
    //Thiet lap mau nen
    [myButton setBackgroundColor:[UIColor blueColor]];
    //Thiet lap Title
    [myButton setTitle:@"Normal State" forState:UIControlStateNormal];
    //Thiet lap mau title
    [myButton setTintColor:[UIColor whiteColor]];
    //Them su kien cho button
    [myButton addTarget:self action:@selector(customActionForButton:) forControlEvents:UIControlEventTouchUpInside];
    //Them button vao view
    [self.view addSubview:myButton];
    
    
}
//Su kien khi bam vao button
-(void)customActionForButton:(id)sender{
    isShow = !isShow;
    //Lay label voi tag
    UILabel *theLabel = (UILabel *)[self.view viewWithTag:10];
    theLabel.text = @"haha";
    
    dispatch_time_t delay = dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC);
    dispatch_after(delay, dispatch_get_main_queue(), ^{
        //Remove label khoi man hinh
        [theLabel removeFromSuperview];
    });
    
    //[theLabel setHidden:!theLabel.isHidden];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
