//
//  AppDelegate.h
//  Demo_Mod1_Bai7
//
//  Created by TNKHANH on 3/25/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

