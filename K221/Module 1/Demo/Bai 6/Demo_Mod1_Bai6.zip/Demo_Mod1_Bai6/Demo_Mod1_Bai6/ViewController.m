//
//  ViewController.m
//  Demo_Mod1_Bai6
//
//  Created by TNKHANH on 3/21/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "ViewController.h"
#import "Student.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.txtName.delegate = self;
    
    //Khoi tao mang StudentList de them Student
    self.studentList = [[NSMutableArray alloc] init];
    //Mac dinh, sinh vien khong phai la ho ngheo
    [self.swIsPoor setOn:false];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)sliderDidChange:(UISlider *)sender {
    self.lblAge.text = [NSString stringWithFormat:@"%.0f", sender.value];
}
- (IBAction)segmentDidChange:(UISegmentedControl *)sender {
  
}

- (IBAction)stepperDidChange:(UIStepper *)sender {
    self.lblMark.text = [NSString stringWithFormat:@"%.2f",sender.value];
}



- (IBAction)addStudent:(id)sender {
    
    //Khoi tao Student
    Student *theStudent = [[Student alloc] init];
    //Set cac thuoc tinh cho doi tuong voi cac gia tri cua cac control tren man hinh
    theStudent.name = self.txtName.text;
    theStudent.phone = self.txtPhone.text;
    theStudent.age = [self.lblAge.text integerValue];
    theStudent.gender = self.smGender.selectedSegmentIndex == 0 ? @"Nam" : @"Nu";
    theStudent.mark = [self.lblMark.text floatValue];
    theStudent.info = self.tvInfo.text;
    theStudent.isPoor = self.swIsPoor.isOn;
    
    //Them sinh vien vua tao vao studentList
    [self.studentList addObject:theStudent];
    [self.sliderAge setValue:self.sliderAge.minimumValue animated:true];
}

- (IBAction)printListStudent:(id)sender {
    for (Student *theStudent in self.studentList) {
        //In thong tin 1 sinh vien
        NSLog(@"Ten: %@",theStudent.name);
        NSLog(@"Dien thoai: %@",theStudent.phone);
        NSLog(@"Tuoi: %ld",theStudent.age);
        NSLog(@"Gioi tinh: %@",theStudent.gender);
        NSLog(@"Diem: %.2f",theStudent.mark);
        NSLog(@"Gioi thieu: %@",theStudent.info);
        NSString *isPoor = theStudent.isPoor ? @"Co" : @"Khong";
        NSLog(@"Ho ngheo: %@",isPoor);
        NSLog(@"--------------------");
        
    }
}
//Ghi nhan su kien touch len man hinh
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.txtName resignFirstResponder];
    [self.tvInfo resignFirstResponder];
    [self.txtPhone resignFirstResponder];
}
#pragma mark UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    //An ban phim
    [textField resignFirstResponder];
    
    return true;
}
#pragma mark UITextViewDelegate
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        //An ban phim
        [textView resignFirstResponder];
    }
    return true;
}
@end
