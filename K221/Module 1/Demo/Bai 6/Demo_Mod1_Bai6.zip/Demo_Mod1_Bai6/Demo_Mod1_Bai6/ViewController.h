//
//  ViewController.h
//  Demo_Mod1_Bai6
//
//  Created by TNKHANH on 3/21/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate,UITextViewDelegate>
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtPhone;
- (IBAction)sliderDidChange:(UISlider *)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblAge;
- (IBAction)segmentDidChange:(UISegmentedControl *)sender;
- (IBAction)stepperDidChange:(UIStepper *)sender;
@property (weak, nonatomic) IBOutlet UILabel *lblMark;
@property (weak, nonatomic) IBOutlet UITextView *tvInfo;
@property (weak, nonatomic) IBOutlet UISwitch *swIsPoor;
- (IBAction)addStudent:(id)sender;
- (IBAction)printListStudent:(id)sender;
@property (weak, nonatomic) IBOutlet UISegmentedControl *smGender;
//Mang chua danh sach student
@property (nonatomic, strong)NSMutableArray *studentList;
@property (weak, nonatomic) IBOutlet UISlider *sliderAge;
@end

