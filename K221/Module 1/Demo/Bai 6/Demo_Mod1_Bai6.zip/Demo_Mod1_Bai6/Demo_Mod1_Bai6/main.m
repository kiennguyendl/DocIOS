//
//  main.m
//  Demo_Mod1_Bai6
//
//  Created by TNKHANH on 3/21/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
