//
//  ViewController.h
//  Demo_Mod1_Bai8
//
//  Created by TNKHANH on 3/28/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtHoTen;
@property (weak, nonatomic) IBOutlet UITextField *txtTuoi;
- (IBAction)indexDidChange:(UIStepper *)sender;
@property (weak, nonatomic) IBOutlet UIStepper *myStepper;
@property (nonatomic, strong) NSArray *userList;

@end

