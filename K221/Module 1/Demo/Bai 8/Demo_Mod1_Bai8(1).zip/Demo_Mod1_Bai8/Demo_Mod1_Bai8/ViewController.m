//
//  ViewController.m
//  Demo_Mod1_Bai8
//
//  Created by TNKHANH on 3/28/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Copy tap tin vao Documents
    [self workingWithFile];
    [self readFile:@"Test.plist"];
}

//Thao tac voi tap tin
-(void)workingWithFile{
    //Lay duong dan den thu muc Documents
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, true) objectAtIndex:0];
    //Duong dan den tap tin Test.plist trong Documents
    NSString *filePath = [documentPath stringByAppendingPathComponent:@"Test.plist"];
    
    NSLog(@"File Path in Documents: %@",filePath);
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //Kiem tra su ton tai cua file
    bool isExist = [fileManager fileExistsAtPath:filePath];
    if (!isExist) {//Neu khong ton tai thi copy
        //Lay duong dan file Test.plist trong Bundle
        NSString *filePathBundle = [[NSBundle mainBundle] pathForResource:@"Test" ofType:@"plist"];
        NSLog(@"FilePath in Bundle %@",filePathBundle);
        NSError *error;
        //Copy tu Bundle -> Documents
        [fileManager copyItemAtPath:filePathBundle toPath:filePath error:&error];
        if (!error) {//Khong co loi, error == nil
            NSLog(@"Copy successfully");
        }
        else{
            NSLog(@"%@",[error localizedDescription]);
        }
        
    }
    else{
        NSLog(@"File existed");
    }
    
}
//Lay duong dan tap tin trong documents
-(NSString *)getFilePathInDocumentsWithName:(NSString *)fileName{
    //Lay duong dan den thu muc Documents
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, true) objectAtIndex:0];
    //Duong dan den tap tin Test.plist trong Documents
    NSString *filePath = [documentPath stringByAppendingPathComponent:fileName];
    
    return filePath;
}

//Doc tap tin
-(void)readFile:(NSString *)fileName{

    NSString *filePath = [self getFilePathInDocumentsWithName:fileName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:filePath]) {
        NSDictionary *myDict = [NSDictionary dictionaryWithContentsOfFile:filePath];
        NSLog(@"%@",myDict[@"HoTen"]);
    }
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
