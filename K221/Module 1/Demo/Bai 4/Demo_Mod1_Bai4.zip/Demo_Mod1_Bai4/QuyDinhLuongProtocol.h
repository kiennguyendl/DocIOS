//
//  QuyDinhLuongProtocol.h
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <Foundation/Foundation.h>
@class GiangVien;
@protocol QuyDinhLuongProtocol <NSObject>
@required
-(void)tinhLuongChoGiangVien:(GiangVien *)gv;
@end
