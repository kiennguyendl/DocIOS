//
//  GiangVien.m
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "GiangVien.h"

@implementation GiangVien
int teacherId;
-(id)initGV{
    self = [super init];
    teacherId = 1;
    self.ma  = [NSString stringWithFormat:@"GV%04d",teacherId];
    teacherId++;;
    return self;
}
-(void)day{
    NSLog(@"Giang vien %@ - %@ - %ld tuoi dang day",self.ma,self.ten,self.tuoi);
}
-(void)soanBai{
    NSLog(@"Giang vien %@ - %@ - %ld tuoi dang soan bai",self.ma,self.ten,self.tuoi);
}
-(void)vaoLop{
    NSLog(@"Giang vien co the vao lop luc 7h");
}
-(void)tinhLuongGiangVien{
    if ([self.delegate respondsToSelector:@selector(tinhLuongChoGiangVien:)]) {
        [self.delegate tinhLuongChoGiangVien:self];
    }
    else{
        //In ra luong can ban
        NSLog(@"Luong can ban la: %d",LUONGCANBAN);
    }
}
@end
