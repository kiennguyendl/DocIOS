//
//  PhuongTien.m
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "PhuongTien.h"

@implementation PhuongTien
//Required
-(void)tinHieuDung:(NSString *)loaiXe doiXe:(NSString *)type{
    NSLog(@"Cac phuong tien dung lai khi co den do");
}

//Optional
-(void)tinHieuRePhai{
    NSLog(@"Phuong tien khi re PHAI can bao hieu");
}
-(void)tinHieuReTrai{
    NSLog(@"Phuong tien khi re TRAI can bao hieu");
}
@end
