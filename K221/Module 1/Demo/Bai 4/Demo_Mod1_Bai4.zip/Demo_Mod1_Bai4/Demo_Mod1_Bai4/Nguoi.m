//
//  Nguoi.m
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "Nguoi.h"

@implementation Nguoi

//Phuong thuc khoi tao mac dinh
-(instancetype)init{
    self.ten = [self layTenNgauNhien];
    self.tuoi = [self layTuoiNgauNhien];
    return self;
}
//Ham lay tuoi ngau nhien tu 18->60
-(NSInteger)layTuoiNgauNhien{
    return arc4random() % 43 + 18;
}
//Ham lay ten ngau nhien
-(NSString *)layTenNgauNhien{
    NSArray *dsTen = @[@"Chuc",@"Tu",@"Hung",@"Thu",@"Nam"];
    return dsTen[arc4random()%dsTen.count];
}

@end
