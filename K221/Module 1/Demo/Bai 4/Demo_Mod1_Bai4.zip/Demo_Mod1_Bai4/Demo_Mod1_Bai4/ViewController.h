//
//  ViewController.h
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LuatDuongBo.h"
#import "QuyDinhLuongProtocol.h"
@interface ViewController : UIViewController<LuatDuongBo,QuyDinhLuongProtocol>


@end

