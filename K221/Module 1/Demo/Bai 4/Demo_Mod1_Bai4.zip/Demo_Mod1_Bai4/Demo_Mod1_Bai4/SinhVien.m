//
//  SinhVien.m
//  Demo_Mod1_Bai3
//
//  Created by TNKHANH on 3/11/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "SinhVien.h"

@implementation SinhVien
int studentId = 1;
-(id)initSV{
    self = [super init];
    self.ma = [NSString stringWithFormat:@"SV%04d",studentId];
    
    studentId++;
    
    return self;
}
-(void)hoc{
    NSLog(@"Sinh vien %@ -  %@ - %ld tuoi dang hoc",self.ma,self.ten,self.tuoi);
}
-(void)lamBaiTap{
     NSLog(@"Sinh vien %@ -  %@ - %ld tuoi dang lam bai tap",self.ma,self.ten,self.tuoi);
}
-(void)vaoLop{
    NSLog(@"Sinh vien phai vao lop truoc 6h45 de truc nhat");
}
@end
