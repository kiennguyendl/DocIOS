//
//  Nguoi.h
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Nguoi : NSObject
//Khai bao thuoc tinh
@property (nonatomic, strong)NSString *ma;
@property (nonatomic, strong)NSString *ten;
@property (nonatomic)NSInteger tuoi;
@end
