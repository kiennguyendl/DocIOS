//
//  SinhVien.h
//  Demo_Mod1_Bai3
//
//  Created by TNKHANH on 3/11/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Nguoi.h"
#import "QuyDinhChungProtocol.h"
@interface SinhVien : Nguoi <QuyDinhChungProtocol>

@property (nonatomic)NSInteger diem;

//Khai bao phuong thuc
-(id)initSV;
-(void)hoc;
-(void)lamBaiTap;
@end
