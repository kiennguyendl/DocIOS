//
//  XeMay.m
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "XeMay.h"

@implementation XeMay
-(void)tinHieuDung:(NSString *)loaiXe doiXe:(NSString *)type{
    NSLog(@"Xe may thay den do phai dung lai");
}
-(void)xeMayChayTrenDuong{
    if ([self.delegate respondsToSelector:@selector(tinHieuDung:doiXe:)]) {
        [self.delegate tinHieuDung:@"cup" doiXe:@"2016"];

    }
    else{
        NSLog(@"Trong do thi, xe may khong duoc chay qua 50km/h");
    }
}
@end
