//
//  GiangVien.h
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "Nguoi.h"
#import "QuyDinhChungProtocol.h"
#import "QuyDinhLuongProtocol.h"
#define LUONGCANBAN 5000000
@interface GiangVien : Nguoi <QuyDinhChungProtocol>

@property (nonatomic, strong)id <QuyDinhLuongProtocol> delegate;
//Khai bao phuong thuc

-(id)initGV;
-(void)day;
-(void)soanBai;

//Khai bao phuong thuc tinh luong
-(void)tinhLuongGiangVien;
@end
