//
//  ViewController.m
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import "ViewController.h"
#import "XeMay.h"
#import "GiangVien.h"
#import "SinhVien.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Tao doi tuong thuoc lop XeMay
    XeMay *xm1 = [XeMay new];
    [xm1 tinHieuDung:@"air blade" doiXe:@"2016"];
    [xm1 tinHieuRePhai];
    [xm1 tinHieuReTrai];
    
    //Uy thac
    xm1.delegate = self;
    //PhuongTien *pt1 = [PhuongTien new];
    
    [xm1 xeMayChayTrenDuong];
    //Khoi tao doi tuong thuoc lop SinhVien
    SinhVien *sv1 = [[SinhVien alloc] initSV];
    [sv1 hoc];
    [sv1 vaoLop];
    
    //Khoi tao doi tuong thuoc lop GiangVien
    GiangVien *gv1 = [[GiangVien alloc] initGV];
    [gv1 day];
    [gv1 vaoLop];

    //Thiet lap delegate
    gv1.delegate = self;
    [gv1 tinhLuongGiangVien];
    
}
-(void)tinhLuongChoGiangVien:(GiangVien *)gv{
    float luong = LUONGCANBAN;
    if (gv.tuoi > 50) {
        luong += 6000000;
    }
    else if (gv.tuoi > 40){
        luong += 4000000;
    }
    else if (gv.tuoi > 30){
        luong += 2000000;
    }

    NSLog(@"Giang vien %@ co luong la: %.0f",gv.ten, luong);
}
-(void)tinHieuRePhai{
    NSLog(@"Re phai");
}
-(void)tinHieuDung:(NSString *)loaiXe doiXe:(NSString *)type{
    NSLog(@"Tin hieu dung ViewController %@ - %@",loaiXe,type);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
