//
//  LuatDuongBo.h
//  Demo_Mod1_Bai4
//
//  Created by TNKHANH on 3/14/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol LuatDuongBo <NSObject>
//Phuong thuc bat buoc cua Protocol
@required
-(void)tinHieuDung:(NSString *)loaiXe doiXe:(NSString *)type;

//Phuong thuc tuy chon cua Protocol
@optional
-(void)tinHieuReTrai;
-(void)tinHieuRePhai;
@end
