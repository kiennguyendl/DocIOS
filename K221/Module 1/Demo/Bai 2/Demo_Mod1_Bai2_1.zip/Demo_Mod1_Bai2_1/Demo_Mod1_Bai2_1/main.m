//
//  main.m
//  Demo_Mod1_Bai2_1
//
//  Created by TNKHANH on 3/4/16.
//  Copyright © 2016 T3H. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
#pragma mark Working with NSString
        //Khoi tao va gan gia tri cho chuoi
        NSString *module = @"Bai 2";
        //Khoi tao chuoi voi dinh dang
        NSString *say = [NSString stringWithFormat:@"Xin chao day la %@",module];
        //In ra man hinh output chuoi say
        NSLog(@"%@",say);
        NSString *say1 = [NSString stringWithFormat:@"Xin chao day la bai %.1f",2.1];
        NSLog(@"%@",say1);
        
        //Noi chuoi
        NSString *say2 = [say stringByAppendingString:say1];
        NSLog(@"%@",say2);
        
        
        NSString *chuoi = @"Trung tam tin hoc Dai hoc Khoa hoc tu nhien";
        //Cat chuoi con tu dau den vi tri 10
        NSLog(@"%@",[chuoi substringToIndex:10]);
        //Cat chuoi tu vi tri 10 den cuoi chuoi
        NSLog(@"%@",[chuoi substringFromIndex:10]);
        //Cat chuoi theo range
        NSRange range = NSMakeRange(10, 5);
        NSLog(@"%@",[chuoi substringWithRange:range]);
        
        //Tach chuoi va dua vao mang theo ky tu duoc truyen vao
        NSArray *mangChuaTen = [chuoi componentsSeparatedByString:@" "];
        NSLog(@"%@",mangChuaTen[6]);
#pragma mark Working with NSDate
        //Lay ngay gio hien tai
        NSDate *toDay = [NSDate date];
        NSLog(@"%@",toDay);
        //Khoi tao doi tuong thuoc lop NSDateFormatter
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        //Thiet lap dinh dang ngay thang cho Formatter
        [dateFormatter setDateFormat:@"EEEE dd-MM-yyyy HH:mm:ss a"];
        //Thiet lap localize cho dateFormatter
        NSLocale *viLocale = [NSLocale localeWithLocaleIdentifier:@"vi"];
        [dateFormatter setLocale:viLocale];
        
        NSString *toDayStr = [dateFormatter stringFromDate:toDay];
        NSLog(@"%@",toDayStr);
#pragma mark BaiTap 2.1
        //khởi tạo một biến myName kiểu NSString để lưu họ tên
        NSString *myName = @"Nguyễn Mai Lĩnh";
        
        //Tạo biến lowercaseName kiểu NSString để lưu trữ tên in thường
        NSString *lowercaseName = [myName lowercaseString];
        //In chuỗi với biến lowercaseName lưu trữ tên viết in thường
        NSLog(@"Xin chào tôi là %@",lowercaseName);
        
        //In ra chuỗi với tên viết hoa - viết gộp 2 bước trên lại
        NSLog(@"Xin chào tôi là %@",[myName uppercaseString]);
        
        //In ra chuỗi theo kiểu in hoa kí tự đầu
        NSLog(@"Xin chào tôi là %@",[myName capitalizedString]);
        
        //Kiểm tra từ đầu tiên trong myName có phải "Nguyễn" không
        if ([myName hasPrefix:@"Nguyễn"]) {//nếu phải
            NSLog(@"Tôi thuộc họ Nguyễn");
        }else{// nếu không
            NSLog(@"Tôi không thuộc họ Nguyễn");
        }
        
        //Tạo biến myAge kiểu NSInteger để lưu tuổi ngẫu nhiên
        //arc4random() % 91 sẽ trả về từ 0 -> 90, cộng thêm 10 sẽ được từ 10 -> 100
        NSInteger myAge = (arc4random() % 91) + 10;
        //In ra tên và tuổi
        NSLog(@"Xin chào tôi là %@! Năm nay tôi tròn %li tuổi!",[myName capitalizedString], (long)myAge);
        
        NSString *name = @"Nguyễn Văn A";
        //So sánh tên với Nguyễn Văn A, nếu kết quả là tăng dần
        if ([myName compare:name] == NSOrderedAscending) {
            NSLog(@"%@",myName);// in tên mình trước
            NSLog(@"%@",name);
        }else{// Nếu kết quả giảm dần
            NSLog(@"%@",name);// In Nguyễn Văn A trước
            NSLog(@"%@",myName);
        }
    }
    return 0;
}
