//
//  Item.h
//  DemoTableViewAsync
//
//  Created by TNKHANH on 6/6/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface Item : NSObject
@property (nonatomic, strong)NSString *key;
@property (nonatomic, strong)NSString *urlImage;
@property (nonatomic, strong)UIImage *image;
@end
