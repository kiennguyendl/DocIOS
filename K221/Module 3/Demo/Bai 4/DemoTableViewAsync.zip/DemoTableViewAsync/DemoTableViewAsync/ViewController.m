//
//  ViewController.m
//  DemoTableViewAsync
//
//  Created by TNKHANH on 6/6/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"
#define kUrlString @"http://www.raywenderlich.com/downloads/ClassicPhotosDictionary.plist"
#import "CustomTableViewCell.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self configTableView];
    [self loadData];
    //[self loadDataWithGCD];
}

-(void)configTableView{
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}

//Tai du lieu tu Dictionary
-(void)loadData{
    NSDictionary *dataDict = [self getDataDictFromUrl:kUrlString];
    self.dataList = [[NSMutableArray alloc] init];
    //Tao ra item tu dataDict va them vao mang dataList
    //Lay tat ca cac key
    NSArray *keys = [dataDict allKeys];
    for (NSString *key in keys) {
        Item *newItem = [Item new];
        newItem.key = key;
        newItem.urlImage = [dataDict objectForKey:key];
        
        //Them item vao mang dataList
        [self.dataList addObject:newItem];
    }
    
    NSLog(@"%@",self.dataList);
}
//Tai du lieu bat dong bo, su dung Operation Queue
-(void)loadDataWithOperationQueue{
    NSDictionary *dataDict = [self getDataDictFromUrl:kUrlString];
    NSOperationQueue *operationQueue = [[NSOperationQueue alloc] init];
    [operationQueue addOperationWithBlock:^{
        //Load item to item List
        self.dataList = [[NSMutableArray alloc] init];
        NSArray *keys = [dataDict allKeys];
        for (NSString *key in keys) {
            //Lay value tuong ung voi key
            NSString *value = [dataDict objectForKey:key];
            //Lay image tu urlString
            UIImage *image = [self loadImageWithUrlString:value];
            if (image) {//Neu tai duoc hinh
                //Tao item vao them vao itemList
                Item *newItem = [Item new];
                newItem.key = key;
                newItem.image = image;
                [self.dataList addObject:newItem];
                
                //Tai lai tableView trong mainQueue
                [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                    [self.tableView reloadData];
                }];
            }
        }
    }];
}
//Tai du lieu bat dong bo, su dung GCD
-(void)loadDataWithGCD{
    NSDictionary *dataDict = [self getDataDictFromUrl:kUrlString];
    self.dataList = [[NSMutableArray alloc] init];
    //Tao hang doi global
    dispatch_queue_t myQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    //Thuc hien tai du lieu bat dong bo cho hang doi vua tao
    dispatch_async(myQueue, ^{
        NSArray *keys = [dataDict allKeys];
        for(NSString *key in keys){
            Item *newItem = [Item new];
            newItem.key = key;
            newItem.urlImage = [dataDict objectForKey:key];
            UIImage *image = [self loadImageWithUrlString:newItem.urlImage];
            if (image) {
                newItem.image = image;
            }
            //Them item vao datalist
            [self.dataList addObject:newItem];
            //Tai lai table view, thuc hien trong main queue
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }
        
    });
}

//Lay du lieu dang dictionary tu urlstring
-(NSDictionary *)getDataDictFromUrl:(NSString *)urlString{
    //Tao Url tu string
    NSURL *dataSourceUrl = [NSURL URLWithString:urlString];
    //Lay dictionary tu url
    return  [[NSDictionary alloc] initWithContentsOfURL:dataSourceUrl];
}
//Tai hinh voi urlString
-(UIImage *)loadImageWithUrlString:(NSString *)urlString{
    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlString]];
    return [UIImage imageWithData:imageData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark table view datasource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataList.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"CellStyle1";
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        [tableView registerNib:[UINib nibWithNibName:@"CellStyle1" bundle:nil] forCellReuseIdentifier:cellId];
        cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    }
    
    
    //Configure cell
    Item *item = self.dataList[indexPath.row];
    
    cell.lblTitle.text = item.key;
    cell.thumbImageView.image = nil;
    
    dispatch_queue_t myQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
   
    dispatch_async(myQueue, ^{
        UIImage *image = [self loadImageWithUrlString:item.urlImage];
        if (image) {
            dispatch_async(dispatch_get_main_queue(), ^{
                CustomTableViewCell *updateCell = (id)[tableView cellForRowAtIndexPath:indexPath];
                if (updateCell)
                    updateCell.thumbImageView.image = image;
                //cell.thumbImageView.image = image;
            });

        }
    });
//
//    if (item.image) {
//        cell.thumbImageView.image = item.image;
//    }
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 180.f;
}
@end
