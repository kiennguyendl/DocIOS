//
//  ViewController.h
//  DemoSearchController
//
//  Created by TNKHANH on 6/17/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchResultsUpdating,UISearchBarDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic)NSArray *dataList;
@property (nonatomic)UISearchController *searchController;
@property (nonatomic)NSMutableArray *searchResults;
@property BOOL isSearching;

@end

