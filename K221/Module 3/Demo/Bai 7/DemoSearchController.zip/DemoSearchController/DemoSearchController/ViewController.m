//
//  ViewController.m
//  DemoSearchController
//
//  Created by TNKHANH on 6/17/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Tai du lieu cho table view
    [self loadData];
    //config search controller
    [self configSearchController];
}

//Cau hinh SearchController - Ham tu DN
-(void)configSearchController{
    //Khoi tao searchController
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    
    //Thiet lap searchResultUpdater delegate
    self.searchController.searchResultsUpdater = self;
    
    //Config search controller
    self.searchController.dimsBackgroundDuringPresentation = true;
    self.searchController.hidesNavigationBarDuringPresentation = false;
    self.searchController.searchBar.placeholder = @"Search here";
    
    //Uy thac SearchBar
    self.searchController.searchBar.delegate = self;
    [self.searchController.searchBar sizeToFit];
    
    //Them search bar cua search controller vao table view header
    self.tableView.tableHeaderView = self.searchController.searchBar;
}

//Doc du lieu tu file countries.txt
-(void)loadData{
    //Lay duong dan tap tin tu Bundle
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"countries" ofType:@"txt"];
    //Kiem tra neu ton tai thi doc file va dua vao datasource
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        NSError *error;
        NSString *countries = [NSString  stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
        if (!error) {
            self.dataList = [countries componentsSeparatedByString:@"\n"];
        }
        
    }
    NSLog(@"%@",self.dataList);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Table View DataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.isSearching == true) {
        return self.searchResults.count;
    }
    return self.dataList.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    //Configure cell
    if (self.isSearching == true) {
        cell.textLabel.text = self.searchResults[indexPath.row];
    }
    else
        cell.textLabel.text = self.dataList[indexPath.row];
    
    return cell;
}
#pragma mark Search Result Updater
-(void)updateSearchResultsForSearchController:(UISearchController *)searchController{
    self.searchResults = [[NSMutableArray alloc] init];
    NSString *searchString = searchController.searchBar.text;
    for (NSString *item in self.dataList) {
        if ([[item lowercaseString] containsString:[searchString lowercaseString]]) {
            [self.searchResults addObject:item];
        }
    }
    if (![searchString isEqualToString:@""]) {
        //Tai lai du lieu cho table view
        [self.tableView reloadData];
    }
}

#pragma mark search bar delegate
//Phuong thuc duoc goi khi bat dau tim kiem
-(void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar{
    self.isSearching = true;
}
//Phuong thuc duoc goi khi ket thuc tim kiem
-(void)searchBarTextDidEndEditing:(UISearchBar *)searchBar{
    self.isSearching = false;
    [self.tableView reloadData];
}
@end
