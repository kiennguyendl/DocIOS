//
//  Student.m
//  DemoCoreData
//
//  Created by TNKHANH on 5/30/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "Student.h"

@implementation Student

// Insert code here to add functionality to your managed object subclass

@end
