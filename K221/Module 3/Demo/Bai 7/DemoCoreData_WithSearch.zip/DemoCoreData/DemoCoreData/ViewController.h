//
//  ViewController.h
//  DemoCoreData
//
//  Created by TNKHANH on 5/30/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"
@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong)NSMutableArray *studentList;
//Khai bao thuoc tinh de Search
@property (nonatomic)UISearchController *searchController;
@property (nonatomic)NSMutableArray *searchResults;
@property BOOL isSearching;

@end

