//
//  DetailViewController.m
//  DemoCoreData
//
//  Created by TNKHANH on 5/30/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    if (_currentStudent) {
        self.title = @"Edit Student";
        self.txtName.text = _currentStudent.name;
        self.txtAge.text = [NSString stringWithFormat:@"%@",_currentStudent.age];
        self.txtAddress.text = _currentStudent.address;
    }
    else
        self.title = @"New Student";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Lay context cua AppDelegate - Ham tu DN
-(NSManagedObjectContext *)managedObjectContext{
    NSManagedObjectContext *context;
    
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    
    
    return context;
    
}
//Update Core Data
-(void)updateCoreDataWithContext:(NSManagedObjectContext *)context andObject:(Student *)student{
   
    student.name = self.txtName.text;
    student.age = [NSNumber numberWithInt:[self.txtAge.text intValue]];
    student.address = self.txtAddress.text;
    
    //Luu context
    NSError *error;
    [context save:&error];
    if (!error) {//Luu thanh cong
        //Hien alert controller thong bao luu thanh cong
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Info" message:@"Save Successfully" preferredStyle:UIAlertControllerStyleAlert];
        
        
        //Them action ok
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *okAction){
            [self.navigationController popViewControllerAnimated:true];
        }];
        
        [alert addAction:okAction];
        //Hien thi alert controller
        [self presentViewController:alert animated:true completion:nil];
    }
    else{
        NSLog(@"%@",[error localizedDescription]);
    }
    
    
}

- (IBAction)save:(id)sender {
    //Lay context cua AppDelegate
    NSManagedObjectContext *context = [self managedObjectContext];
    if (_currentStudent) {
        //Cap nhat Student
        [self updateCoreDataWithContext:context andObject:_currentStudent];
    }
    else{
        //Them moi student
        Student *newStudent = [NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:context];
        //Cap nhat core data
        [self updateCoreDataWithContext:context andObject:newStudent];
        
    }
}
@end
