//
//  ViewController.m
//  Demo_Animation
//
//  Created by TNKHANH on 6/10/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end


@implementation ViewController
enum animationType{
    Move = 0,
    Scale = 1,
    Rotate = 2,
    Alpha = 3,
    Corner = 4
};

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)animationChanged:(UISegmentedControl *)sender {
    enum animationType type = (int)sender.selectedSegmentIndex;
    CGRect originalImageViewFrame = self.imageView.frame;
    switch (type) {
        case Move:{
            //Lay frame goc cua imageView
            CGRect oFrame = self.imageView.frame;
            int y1 = 300;
            //Thay doi frame
            oFrame.origin.y += y1;
            //Thuc hien animation
            [UIView animateWithDuration:1.0 animations:^{
                //Thay doi frame.y cua imageView
                self.imageView.frame = oFrame;
            } completion:^(BOOL finishe){
                [UIView animateWithDuration:1.0 animations:^{
                    self.imageView.frame = originalImageViewFrame;
                }];
            }];
            break;
        }
        case Scale:{
            int x = originalImageViewFrame.origin.x - originalImageViewFrame.size.width/2;
            int y = originalImageViewFrame.origin.y - originalImageViewFrame.size.height/2;
            
            [UIView animateWithDuration:1.0 animations:^{
                //Thay doi kich thuoc cua imageView
                [self.imageView setFrame:CGRectMake(x, y, originalImageViewFrame.size.width*2, originalImageViewFrame.size.height*2)];
            } completion:^(BOOL finishe){
                [UIView animateWithDuration:1.0 animations:^{
                    self.imageView.frame = originalImageViewFrame;
                }];
            }];
            break;
        }
        case Alpha:{
            [UIView animateWithDuration:1.0 animations:^{
                
                self.imageView.alpha = 0.3;
            } completion:^(BOOL finishe){
                [UIView animateWithDuration:1.0 animations:^{
                    self.imageView.alpha = 1.0;
                }];
            }];

        }
        case Rotate:{
            //Tinh goc xoay theo radians
            float degree = 90;
            float radians = degree/180 * M_PI;
            //Thuc hien animation
            [UIView animateWithDuration:1.0 animations:^{
                //Xoay imageView theo goc radian
                self.imageView.transform = CGAffineTransformMakeRotation(radians);
                
            } completion:^(BOOL finished){
                [UIView animateWithDuration:1.0 animations:^{
                    self.imageView.transform = CGAffineTransformIdentity;
                }];
            }];
            
            break;
        }
        case Corner:{
            self.imageView.layer.cornerRadius = self.imageView.frame.size.width/2;
            self.imageView.clipsToBounds = true;
            break;
        }
        default:
            break;
    }
}
- (IBAction)customAnimation:(id)sender {
    UIButton *btn = (UIButton*)sender;
    btn.enabled = false;
    [self combineAnimation:btn];
}
-(void)combineAnimation:(UIButton *)sender{
    CGRect oFrame = self.imageView.frame;
    CGRect newFrame = self.imageView.frame;
    int x1 = 80;
    newFrame.origin.x += x1;
    [UIView animateWithDuration:1.0 animations:^{
        self.imageView.frame = newFrame;
        self.imageView.alpha = 0.3;
    } completion:^(BOOL finished){
        int y1 = 300;
        CGRect nFrame = self.imageView.frame;
        nFrame.origin.y += y1;
        [UIView animateWithDuration:1.0 animations:^{
            self.imageView.alpha = 1.0;
            self.imageView.frame = nFrame;
        } completion:^(BOOL finished){
            CGRect n1Frame = self.imageView.frame;
            n1Frame.origin.x -= x1;
            [UIView animateWithDuration:1.0 animations:^{
                self.imageView.frame = n1Frame;
                self.imageView.alpha = 0.3;
            } completion:^(BOOL finished){
                [UIView animateWithDuration:1.0 animations:^{
                    self.imageView.frame = oFrame;
                    self.imageView.alpha = 1.0;
                } completion:^(BOOL finished){
                    //sender.enabled = true;
                }];
            }];
        }];
    }];
    
    //Thiet lap timer thuc hien lai ham nay sau moi 4 giay
    self.myTimer = [[NSTimer alloc] init];
    self.myTimer = [NSTimer scheduledTimerWithTimeInterval:4 target:self selector:@selector(combineAnimation:) userInfo:nil repeats:false];
    
}

//Xu ly khi cham man hinh
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //Vo hieu hoa timer
    [self.myTimer invalidate];
}
@end
