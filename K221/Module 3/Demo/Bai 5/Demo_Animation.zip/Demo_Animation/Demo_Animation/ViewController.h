//
//  ViewController.h
//  Demo_Animation
//
//  Created by TNKHANH on 6/10/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
- (IBAction)animationChanged:(UISegmentedControl *)sender;
//@property (nonatomic)CGRect oFrame;
- (IBAction)customAnimation:(id)sender;
@property (nonatomic, strong)NSTimer *myTimer;
@end

