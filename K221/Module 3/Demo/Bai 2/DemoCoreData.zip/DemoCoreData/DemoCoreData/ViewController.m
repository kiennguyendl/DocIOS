//
//  ViewController.m
//  DemoCoreData
//
//  Created by TNKHANH on 5/30/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"
#import "DetailViewController.h"
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}
-(void)viewWillAppear:(BOOL)animated{
    [self getData];
    [self.tableView reloadData];
}
//Lay context cua AppDelegate - Ham tu DN
-(NSManagedObjectContext *)managedObjectContext{
    NSManagedObjectContext *context;
    
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    
    
    return context;
    
}
//Lay du lieu tu Core Data
-(void)getData{
    //Lay context
    NSManagedObjectContext *context = [self managedObjectContext];
    //Tao fetchRequest
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Student"];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"%K contains %@",@"name",@"a"];
    [fetchRequest setPredicate:predicate];
    
    NSError *error;
    //Lay du lieu tu core data = fetchRequest
    NSArray *result = [context executeFetchRequest:fetchRequest error:&error];
    if (!error) {
        _studentList = [[NSMutableArray alloc] initWithArray:result];
    }
    else{
        NSLog(@"%@",[error localizedDescription]);
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark Table View Datasource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _studentList.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    
    Student *currentStudent = _studentList[indexPath.row];
    cell.textLabel.text = currentStudent.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",currentStudent.age];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
#pragma mark Table View Delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DetailViewController *detailView = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    //PassData
    Student *currentStudent = _studentList[indexPath.row];
    detailView.currentStudent = currentStudent;
    //Push view
    [self.navigationController pushViewController:detailView animated:true];
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //Xoa du lieu khoi core data
        //Lay context
        NSManagedObjectContext *context = [self managedObjectContext];
        //Lay student can xoa
        Student *currentStudent = _studentList[indexPath.row];
        //Xoa doi tuong khoi CoreData
        [context deleteObject:currentStudent];
        NSError *error;
        [context save:&error];
        
        if (!error) {//Xoa thanh cong
            [_studentList removeObject:currentStudent];
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
        else
            NSLog(@"%@",[error localizedDescription]);
        
    }
}

@end
