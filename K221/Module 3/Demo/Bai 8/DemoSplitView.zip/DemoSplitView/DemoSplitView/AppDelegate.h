//
//  AppDelegate.h
//  DemoSplitView
//
//  Created by TNKHANH on 6/20/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

