//
//  SettingViewController.m
//  DemoSplitView
//
//  Created by TNKHANH on 6/20/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "SettingViewController.h"
#import "GeneralViewController.h"
#import "GameCenterViewController.h"
@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 2;
    }
    if (section == 1) {
        return 6;
    }
    if (section == 2) {
        return 4;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    //Configure
    switch (indexPath.section) {
        case 0://2 rows
            if (indexPath.row == 0) {
                cell.imageView.image = [UIImage imageNamed:@"General.png"];
                cell.textLabel.text = @"General";
            }
            else
                cell.textLabel.text = @"Privacy";
            break;
        case 1:// 6 rows
            switch (indexPath.row) {
                case 0:
                    cell.textLabel.text = @"iCloud";
                    break;
                case 1:
                    cell.textLabel.text = @"Maps";
                    break;
                case 2:
                    cell.textLabel.text = @"News";
                    break;
                case 3:
                    cell.textLabel.text = @"Safari";
                    break;
                case 4:
                    cell.textLabel.text = @"Photos & Camera";
                    
                    break;
                default:
                    cell.imageView.image = [UIImage imageNamed:@"GameCenter.png"];
                    cell.textLabel.text = @"Game Center";
                    break;
            }
            break;
        case 2://4 rows
            switch (indexPath.row) {
                case 0:
                    cell.textLabel.text = @"Twitter";
                    break;
                case 1:
                    cell.textLabel.text = @"Facebook";
                    break;
                case 2:
                    cell.textLabel.text = @"Flickr";
                    break;
                default:
                    cell.textLabel.text = @"Vimeo";
                    break;
            }
            break;
            
        default:
            cell.textLabel.text = @"Developer";
            
            break;
    }
    
    
    return cell;
}
#pragma mark Table view Delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //Khoi tao mang cac view thuoc Detail view cua splitview
    UISplitViewController *detailViewControllers = self.splitViewController.viewControllers[1];
     NSMutableArray *viewArray = [[NSMutableArray alloc] initWithArray:[detailViewControllers viewControllers]];
    if (indexPath.section == 0 && indexPath.row == 0) {
        //General view
        GeneralViewController *detailView = [self.storyboard instantiateViewControllerWithIdentifier:@"GeneralViewController"];
        [viewArray removeLastObject];
        [viewArray addObject:detailView];
    }
    if (indexPath.section == 1 && indexPath.row == 5) {
        GameCenterViewController *detailView = [self.storyboard instantiateViewControllerWithIdentifier:@"GameCenterViewController"];
        [viewArray removeLastObject];
        [viewArray addObject:detailView];
    }
    
    [detailViewControllers setViewControllers:viewArray];
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
