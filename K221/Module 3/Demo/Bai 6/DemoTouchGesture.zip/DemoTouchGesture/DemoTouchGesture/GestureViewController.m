//
//  GestureViewController.m
//  DemoTouchGesture
//
//  Created by TNKHANH on 6/13/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "GestureViewController.h"

@interface GestureViewController ()

@end

@implementation GestureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //Khoi tao mang colorList
    self.colorList = @[[UIColor redColor],[UIColor greenColor],[UIColor blueColor],[UIColor yellowColor],[UIColor whiteColor]];
    
    //Khoi tao Tap Gesture Recognizer
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] init];
    //Qui dinh so lan cham
    [doubleTap setNumberOfTapsRequired:2];
    //Them action cho su kien double tap
    [doubleTap addTarget:self action:@selector(doubleTap)];
    
    //Tem gesture recognizer vao view
    //[self.view addGestureRecognizer:doubleTap];
    
    //Them single tap gesture
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] init];
    
    [singleTap addTarget:self action:@selector(singleTap)];
    
    //[self.view addGestureRecognizer:singleTap];
}
//Ham xu ly su kien single tap
-(void)singleTap{
    //Vo hieu hoa timer
    [self.myTimer invalidate];
}

//Ham xu ly su kien dobleTap
-(void)doubleTap{
    //NSLog(@"double tap");
    self.myTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(changeBGColor) userInfo:nil repeats:true];
    
}

//Doi mau man hinh
-(void)changeBGColor{

    self.view.backgroundColor = self.colorList[self.myIndex%(self.colorList.count)];
    self.myIndex ++ ;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
float degree;
- (IBAction)handleTap:(UITapGestureRecognizer *)sender {
    /*
    //Lay vi tri diem cham tren man hinh
    CGPoint tapPoint = [sender locationInView:self.view];
    [UIView animateWithDuration:1.0 animations:^{
        self.imageView.center = tapPoint;
    }];
     */
    degree += 90;
    float radian = degree/180 * M_PI;
    [UIView animateWithDuration:0.3 animations:^{
        self.imageView.transform = CGAffineTransformMakeRotation(radian);
    }];
    
}

- (IBAction)handlePan:(UIPanGestureRecognizer *)sender {
    CGPoint point = [sender translationInView:self.view];
    sender.view.center = CGPointMake(sender.view.center.x+point.x,sender.view.center.y+point.y);
    [sender setTranslation:CGPointMake(0, 0) inView:self.view];
}

- (IBAction)handlePinch:(UIPinchGestureRecognizer *)sender {
    sender.view.transform = CGAffineTransformScale(sender.view.transform, sender.scale,sender.scale);
    sender.scale = 1;
    
}

- (IBAction)handleRotation:(UIRotationGestureRecognizer *)sender {
    sender.view.transform = CGAffineTransformRotate(sender.view.transform, sender.rotation);
    sender.rotation = 0;
}
@end
