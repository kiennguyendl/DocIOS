//
//  ViewController.h
//  DemoTouchGesture
//
//  Created by TNKHANH on 6/13/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lblPhase;
@property (weak, nonatomic) IBOutlet UILabel *lblTouch;
@property (weak, nonatomic) IBOutlet UILabel *lblTap;


@end

