//
//  GestureViewController.h
//  DemoTouchGesture
//
//  Created by TNKHANH on 6/13/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GestureViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic)NSArray *colorList;
@property NSTimer *myTimer;
@property NSInteger myIndex;
- (IBAction)handleTap:(UITapGestureRecognizer *)sender;
- (IBAction)handlePan:(UIPanGestureRecognizer *)sender;
- (IBAction)handlePinch:(UIPinchGestureRecognizer *)sender;
- (IBAction)handleRotation:(UIRotationGestureRecognizer *)sender;

@end
