//
//  ViewController.m
//  DemoTouchGesture
//
//  Created by TNKHANH on 6/13/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Ghi nhan su kien khi bat dau cham vao man hinh
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //Dem so luong diem cham tren man hinh
    NSInteger touchCount = touches.count;
    
    //Dem so lan cham
    UITouch *myTouch = touches.anyObject;
    NSInteger tapCount = myTouch.tapCount;
    
    //Update UI
    self.lblPhase.text = @"Touch began";
    self.lblTouch.text = [NSString stringWithFormat:@"%ld",touchCount];
    self.lblTap.text = [NSString stringWithFormat:@"%ld",tapCount];
}
//Ghi nhan su kien khi bat dau di chuyen diem cham
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //Dem so luong diem cham tren man hinh
    NSInteger touchCount = touches.count;
    
    //Dem so lan cham
    UITouch *myTouch = touches.anyObject;
    NSInteger tapCount = myTouch.tapCount;
    
    //Update UI
    self.lblPhase.text = @"Touch moved";
    self.lblTouch.text = [NSString stringWithFormat:@"%ld",touchCount];
    self.lblTap.text = [NSString stringWithFormat:@"%ld",tapCount];
}
//Ghi nhan su kien khi ket thuc cham
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //Dem so luong diem cham tren man hinh
    NSInteger touchCount = touches.count;
    
    //Dem so lan cham
    UITouch *myTouch = touches.anyObject;
    NSInteger tapCount = myTouch.tapCount;
    
    //Update UI
    self.lblPhase.text = @"Touch ended";
    self.lblTouch.text = [NSString stringWithFormat:@"%ld",touchCount];
    self.lblTap.text = [NSString stringWithFormat:@"%ld",tapCount];
}

@end
