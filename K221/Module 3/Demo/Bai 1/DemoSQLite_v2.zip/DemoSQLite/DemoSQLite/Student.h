//
//  Student.h
//  DemoSQLite
//
//  Created by TNKHANH on 5/20/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject
@property (nonatomic)int uid;
@property (nonatomic,strong)NSString *name;
@property (nonatomic)int age;
@property (nonatomic, strong)NSString *phone;
@property (nonatomic, strong)NSString *address;
@end
