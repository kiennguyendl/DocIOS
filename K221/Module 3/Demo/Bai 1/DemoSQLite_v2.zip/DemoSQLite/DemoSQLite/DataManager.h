//
//  DataManager.h
//  DemoSQLite
//
//  Created by TNKHANH on 5/20/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "Student.h"
@interface DataManager : NSObject
@property (nonatomic)sqlite3 *DB;
@property (nonatomic)NSString *dataPath;
//@property (nonatomic, strong)NSMutableArray *listStudent;
//Lay danh sach Student
-(NSMutableArray*)getAllStudent;
-(BOOL)saveStudent:(Student *)theStudent;
-(BOOL)deleteStudent:(Student *)theStudent;
@end
