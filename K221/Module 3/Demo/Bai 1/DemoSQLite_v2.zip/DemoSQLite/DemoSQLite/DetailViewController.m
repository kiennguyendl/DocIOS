//
//  DetailViewController.m
//  DemoSQLite
//
//  Created by TNKHANH on 5/23/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "DetailViewController.h"

#import "DataManager.h"
@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.currentStudent) {//Update
        self.title = @"Edit student";
        //Update UI
        self.txtName.text = self.currentStudent.name;
        self.txtAge.text = [NSString stringWithFormat:@"%d",self.currentStudent.age];
        self.txtPhone.text = self.currentStudent.phone;
        self.txtAddress.text = self.currentStudent.address;
    }
    else //Insert
        self.title = @"New student";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)save:(id)sender {
    //Khoi tao student moi
    Student *newStudent = [Student new];
    if (self.currentStudent) {//Neu la dang cap nhat
        newStudent = self.currentStudent;
    }
    
    newStudent.name = self.txtName.text;
    newStudent.age = [self.txtAge.text intValue];
    newStudent.phone = self.txtPhone.text;
    newStudent.address = self.txtAddress.text;
    
    //Goi ham o Datamanager de luu du lieu xuong DB
    if ([[DataManager alloc] saveStudent:newStudent]) {//Neu luu thanh cong
        //Tao alert controller voi style Alert
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Info" message:@"Save Successfully" preferredStyle:UIAlertControllerStyleAlert];
        
        
        //Them action ok
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *okAction){
            [self.navigationController popViewControllerAnimated:true];
        }];
        
        [alert addAction:okAction];
        //Hien thi alert controller
        [self presentViewController:alert animated:true completion:nil];
    }
    else{
        NSLog(@"Unsuccessfully");
    }
    
}

@end
