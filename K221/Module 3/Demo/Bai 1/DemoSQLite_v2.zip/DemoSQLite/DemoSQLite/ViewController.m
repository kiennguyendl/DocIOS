//
//  ViewController.m
//  DemoSQLite
//
//  Created by TNKHANH on 5/20/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"
#import "DetailViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.tableView.dataSource = self;
    self.tableView.delegate = self;

}
-(void)viewWillAppear:(BOOL)animated{
    //Get data
    self.studentList = [[DataManager alloc] getAllStudent];
    [self.tableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.studentList.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }
    Student *currentStudent = self.studentList[indexPath.row];
    cell.textLabel.text = currentStudent.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d",currentStudent.age];
    
    return cell;
    
}

#pragma mark Table View Delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //Khoi tao detail view voi Storyboard id
    DetailViewController *detailView = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    //Pass data
    Student *currentStudent = self.studentList[indexPath.row];
    detailView.currentStudent = currentStudent;
    
    //Push view
    [self.navigationController pushViewController:detailView animated:true];
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        Student *currentStudent = self.studentList[indexPath.row];
        
        //Xoa khoi DB
        if ([[DataManager alloc] deleteStudent:currentStudent]) {
            [self.studentList removeObject:currentStudent];
            //[self.tableView reloadData];
            //Xoa khoi tableview
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }
       
    }
}
- (IBAction)sortStudent:(id)sender {
    //Mo ta tieu chi sap xep
    NSSortDescriptor *nameDescriptor = [[NSSortDescriptor alloc] initWithKey:@"name" ascending:false];
    NSSortDescriptor *ageDescriptor = [[NSSortDescriptor alloc] initWithKey:@"age" ascending:true];
    //Tao mang cac tieu chi sap xep
    NSArray *sortDescriptors  = @[nameDescriptor,ageDescriptor];
    
    //Sap xep mang su dung Descriptors
    //NSArray *sortedStudentList = [self.studentList sortedArrayUsingDescriptors:sortDescriptors];
    
    //self.studentList = [[self.studentList sortedArrayUsingDescriptors:sortDescriptors] copy];
    //self.studentList = [sortedStudentList copy];
    
    [self.studentList sortUsingDescriptors:sortDescriptors];
    //Tai lai tableView
    [self.tableView reloadData];
}
@end
