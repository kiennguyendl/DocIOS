//
//  DetailViewController.h
//  DemoSQLite
//
//  Created by TNKHANH on 5/23/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"
@interface DetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtAge;
@property (weak, nonatomic) IBOutlet UITextField *txtPhone;
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;
- (IBAction)save:(id)sender;
@property (nonatomic, strong)Student *currentStudent;
@end
