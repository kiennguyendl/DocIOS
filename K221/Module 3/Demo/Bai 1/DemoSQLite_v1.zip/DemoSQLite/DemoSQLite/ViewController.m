//
//  ViewController.m
//  DemoSQLite
//
//  Created by TNKHANH on 5/20/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.tableView.dataSource = self;
    self.tableView.delegate = self;

}
-(void)viewWillAppear:(BOOL)animated{
    //Get data
    self.studentList = [[DataManager alloc] getAllStudent];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.studentList.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellId = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }
    Student *currentStudent = self.studentList[indexPath.row];
    cell.textLabel.text = currentStudent.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%d",currentStudent.age];
    
    return cell;
    
}


@end
