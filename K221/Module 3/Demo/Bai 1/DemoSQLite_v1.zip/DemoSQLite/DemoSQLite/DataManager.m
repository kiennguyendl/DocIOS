//
//  DataManager.m
//  DemoSQLite
//
//  Created by TNKHANH on 5/20/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import "DataManager.h"

@implementation DataManager

-(NSString *)getDataPath{
    NSString *filePath = [NSHomeDirectory() stringByAppendingString:@"/Documents/DemoSQLite.sqlite"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:filePath]) {
        //Neu khong ton tai thi copy tu Bundle sang Documents
        NSString *filePathBundle = [[NSBundle mainBundle] pathForResource:@"DemoSQLite" ofType:@"sqlite"];
        NSError *error;
        [fileManager copyItemAtPath:filePathBundle toPath:filePath error:&error];
        
        if (!error) {
            NSLog(@"Copy successfully");
        }
        else{
            NSLog(@"%@",[error localizedDescription ]);
        }
    }
    else{
        NSLog(@"File existed at path: %@",filePath);
    }
    
    return filePath;
}
-(NSMutableArray*)getAllStudent{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    //Lay duong den file sqlite trong Documents
    
    NSString *filePath =  [self getDataPath];
    const char *dbPath = [filePath UTF8String];
    
    //Mo ket noi
    if (sqlite3_open(dbPath, &_DB) == SQLITE_OK) {
        //Khoi tao statement
        sqlite3_stmt *statement;
        //Tao cau truy van
        NSString *query = @"SELECT * FROM Student";
        const char *query_stmt = [query UTF8String];
        //Khoi tao truy van
        if (sqlite3_prepare_v2(_DB, query_stmt, -1, &statement, nil) == SQLITE_OK) {
            //Thuc thi truy van
            while (sqlite3_step(statement) == SQLITE_ROW) {
                int uid = sqlite3_column_int(statement, 0);
                char *name = (char *)sqlite3_column_text(statement, 1);
                int age = sqlite3_column_int(statement, 2);
                char *phone = (char *)sqlite3_column_text(statement, 3);
                char *address = (char *)sqlite3_column_text(statement, 4);
               //Tao Student
                Student *newStudent = [Student new];
                newStudent.uid = uid;
                newStudent.name = name == NULL ? nil : [[NSString alloc] initWithUTF8String:name];
                newStudent.age = age;
                newStudent.phone = phone == NULL ? nil : [[NSString alloc] initWithUTF8String:phone];
                newStudent.address = address == NULL ? nil : [[NSString alloc] initWithUTF8String:address];
                
                //Them student vao mang result
                [result addObject:newStudent];
                
            }
            sqlite3_finalize(statement);
        }
        sqlite3_close(_DB);
    }
    return result;
}
@end
