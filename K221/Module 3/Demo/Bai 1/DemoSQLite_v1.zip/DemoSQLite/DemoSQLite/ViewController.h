//
//  ViewController.h
//  DemoSQLite
//
//  Created by TNKHANH on 5/20/16.
//  Copyright © 2016 T3h. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataManager.h"
#import "Student.h"
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong)NSMutableArray *studentList;

@end

